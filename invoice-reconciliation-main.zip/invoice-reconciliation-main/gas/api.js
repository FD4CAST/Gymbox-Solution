const SCRIPT_URL = () =>
  "https://script.google.com/macros/s/AKfycbyW02lS4EIQfD6n6vsdpamybliM-E4j1YX3n7LiMp-ZdeCPlxPUlO46oU1BAjWBtlq7Qg/exec";

const ID_COLUMN_NAME = "ID";
const ADMIN_SECRET = "rtx4";
const SENT_EMAIL_ID = "pritamiitian@gmail.com";
const TWILIO_SID = "1J";
const TWILIO_AUTH_TOKEN = "1J";
const TWILIO_PHONE_NUMBER = "whatsapp:+14155238886";

const getStringiFiedTables = (sheetNames) => {
  var tables = {};
  sheetNames.forEach((sheetName) => {
    const vals = SpreadsheetApp.getActiveSpreadsheet()
      .getSheetByName(sheetName)
      .getDataRange()
      .getValues();
    tables[sheetName] = vals;
  });
  return JSON.stringify(tables);
};

function includes(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function doGet(e) {
  var page = "index";
  var u = "";
  let data = {};
  if (e.queryString) {
    if (e.parameter.u) {
      u = e.parameter.u;
      let s = e.parameter.s;
      if (u === "admin" && s === ADMIN_SECRET) {
        data.isAdmin = true;
      } else {
        data.isAdmin = false;
        const userFromPS =
          PropertiesService.getScriptProperties().getProperty(u);
        const pin = JSON.parse(userFromPS).pin.toString();
        if (pin && pin === s) {
          data.user = userFromPS;
        } else {
          page = "notAuthorized";
        }
      }
    }
  } else {
    page = "notAuthorized";
  }

  var t = HtmlService.createTemplateFromFile(page);
  t.data = JSON.stringify(data);
  return t
    .evaluate()
    .setTitle("GymBoxing")
    .setSandboxMode(HtmlService.SandboxMode.IFRAME);
}

function saveToProperties(key, value) {
  value = value.toString();
  PropertiesService.getScriptProperties().setProperty(key, value + "");
  return true;
}
function saveInstructorsToScriptProperties(instructors) {
  // Delete all properties:
  PropertiesService.getScriptProperties().deleteAllProperties();
  instructors.forEach((instructor) => {
    saveToProperties(
      instructor.email,
      JSON.stringify({ pin: instructor.pin, id: instructor.id })
    );
  });
  return true;
}
function sendElksSMS(msg, contacts) {
  var username = "u3b1b3f9c95936a9811614b27f539abe6";
  var password = "81FA6D8CF5B4D84D81141AD6934155A1";

  var sender = "+919624701102";
  var auth = Utilities.base64Encode(username + ":" + password);

  contacts = contacts.join();
  try {
    UrlFetchApp.fetch("https://api.46elks.com/a1/SMS", {
      method: "post",
      headers: { Authorization: "Basic " + auth },
      payload: {
        from: sender,
        dryrun: "yes",
        to: contacts,
        message: msg,
      },
    });

    return true;
  } catch (err) {
    return false;
  }
}

function sendWhatsAppMessages(messages) {
  const accountSid = TWILIO_SID;
  const authToken = TWILIO_AUTH_TOKEN;
  const fromWhatsAppNumber = TWILIO_PHONE_NUMBER;

  const url =
    "https://api.twilio.com/2010-04-01/Accounts/" +
    accountSid +
    "/Messages.json";

  messages.forEach((messageObj) => {
    const payload = {
      To: "whatsapp:" + messageObj.phone,
      From: fromWhatsAppNumber,
      Body: messageObj.message,
    };

    const options = {
      method: "post",
      payload: payload,
      headers: {
        Authorization:
          "Basic " + Utilities.base64Encode(accountSid + ":" + authToken),
      },
    };

    try {
      const response = UrlFetchApp.fetch(url, options);
      const responseData = JSON.parse(response.getContentText());
      Logger.log(
        "Message sent successfully to " +
          messageObj.phone +
          ". SID: " +
          responseData.sid
      );
    } catch (error) {
      Logger.log(
        "Failed to send message to " + messageObj.phone + ": " + error.message
      );
    }
  });
}

function savePDF(pdfBlob, payload, fdr_name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var SSID = ss.getId();
  var fileInDrive = DriveApp.getFolderById(SSID);
  var parent_id = fileInDrive.getParents().next().getId();
  var par_fdr = DriveApp.getFolderById(parent_id); // replace the ID
  // var fdr_name = "Invoices";
  try {
    var newFdr = par_fdr.getFoldersByName(fdr_name).next();
  } catch (e) {
    var newFdr = par_fdr.createFolder(fdr_name);
  }

  try {
    var blob = Utilities.newBlob(
      Utilities.base64Decode(pdfBlob.data),
      pdfBlob.mimeType,
      pdfBlob.fileName
    );
    var file = newFdr.createFile(blob);
    const { form, action, id, sheetName } = JSON.parse(payload);

    form.fileId = file.getId();

    return executeAction({
      action,
      sheetName,
      id,
      data: { form: JSON.stringify(form), id: id },
    });
  } catch (e) {
    return e.message;
  }
}

function sendInvoice(payload) {
  // return payload;
  const { form, action, id, sheetName, selectedGym } = JSON.parse(payload);
  const email = SENT_EMAIL_ID || selectedGym.email;
  const month = new Date(form.month).toLocaleString("default", {
    month: "short",
    year: "numeric",
  });
  const subject = `Elite Combat Agency Invoice – ${month}`;
  const fileBlob = DriveApp.getFileById(form.fileId).getBlob();
  var htmlbody = `
  <html>
<body>
  <p>Dear ${selectedGym.contacts},</p>
  <p>Please find attached our invoice for ${month}.</p>
  <p>Thank-you for your continued business. </p>
  <p>Finance Department, Elite Combat Agency</p>
</body>
</html>
`;

  try {
    MailApp.sendEmail(email, subject, "", {
      attachments: [fileBlob],
      htmlBody: htmlbody,
    });
    form.status = "Invoice Sent";
    return executeAction({
      action,
      sheetName,
      id,
      data: { form: JSON.stringify(form), id: id },
    });
  } catch (e) {
    return e.message;
  }
}

function sendRemittanceAdvice(payload) {
  // return payload;
  const { form, action, id, sheetName, selectedCoach } = JSON.parse(payload);
  const email = SENT_EMAIL_ID || selectedCoach.email;
  const month = new Date(form.month).toLocaleString("default", {
    month: "short",
    year: "numeric",
  });
  const subject = `Elite Combat Agency Remittance – ${month}`;
  const fileBlob = DriveApp.getFileById(form.fileId).getBlob();
  var htmlbody = `
  <html>
<body>
  <p>Dear ${selectedCoach?.name},</p>
  <p>Please find attached your remittance for ${month}.</p>
  <p>Finance Department, Elite Combat Agency</p>
</body>
</html>
`;

  try {
    MailApp.sendEmail(email, subject, "", {
      attachments: [fileBlob],
      htmlBody: htmlbody,
    });
    form.status = "Sent";
    return executeAction({
      action,
      sheetName,
      id,
      data: { form: JSON.stringify(form), id: id },
    });
  } catch (e) {
    return e.message;
  }
}

function sendAccessURL({ pin, email, name }) {
  let url = `${SCRIPT_URL()}?u=${email}&s=${pin}`;
  const subject = `Elite Combat Agency – Personal Web APP Access URL for ${name}`;
  const htmlBody = `
  <html>
  <body>
    <p>Dear ${name},</p>
    <p>Welcome to the <strong> Elite Combat Agency Instructor Invoicing & Remittance Portal.</strong></p>
    <p>You will need to use this Application in order to submit monthly timesheets for payment.</p>
    <p>Failure to submit a timesheet by the final day of each calendar month may result in delayed payment.</p>
    <p><strong>Please note that the Web Application is only fully compatible when used on a Chrome Browser, so you will need to install Chrome on your device in order to use it properly. This is important as you may encounter errors if you try to use an alternative browser.</strong></p>
    <p>Click <a href="${url}">here</a> the Web Application using your personal URL.</p>
    <p>Kind regards,</p>
    <p>Elite Combat Agency</p>
  </body>
  </html>
  `;
  MailApp.sendEmail(email, subject, "", {
    htmlBody,
  });

  return true;
}

function sendWhatsapp() {
  // click to chat link
}

function sendInvoiceRequestEmails(coaches) {
  let dt = new Date();
  dt.setMonth(dt.getMonth() - 1);
  const month = dt.toLocaleString("default", {
    month: "short",
    year: "numeric",
  });
  coaches.forEach((coach) => {
    const email = SENT_EMAIL_ID || coach.email;
    const subject = `Elite Combat Agency – Invoice Request for ${month}`;
    const htmlBody = `
    <html>
    <body>
      <p>Dear ${coach.name},</p>
      <p>Elite Combat Agency requires your invoice for the month of ${month}.</p>
      <p>Please submit your invoice by the final day of the month.</p>
      <p>Kind regards,</p>
      <p>Elite Combat Agency</p>
    </body>
    </html>
    `;
    MailApp.sendEmail(email, subject, "", {
      htmlBody,
    });
  });
  return true;
}

function sendInvoiceRequestWhatsApp(coaches) {
  let dt = new Date();
  dt.setMonth(dt.getMonth() - 1);
  const month = dt.toLocaleString("default", {
    month: "short",
    year: "numeric",
  });
  const messages = coaches.map((coach) => {
    return {
      phone: coach.phone,
      message: `Elite Combat Agency requires your invoice for the month of ${month}. Please submit your invoice by the final day of the month.`,
    };
  });

  sendWhatsAppMessages(messages);
  return true;
}
