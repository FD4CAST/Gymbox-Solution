const apendRow = ["id", "form"];

const DoSetup = (sheetNames) => {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  sheetNames.forEach((sheetName) => {
    const sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      ss.insertSheet(sheetName).appendRow(apendRow);
    }
  });
};

const DoHardReset = (sheetNames) => {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  sheetNames.forEach((sheetName) => {
    const sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      ss.insertSheet(sheetName);
    }
    sheet.clear();
    sheet.appendRow();
  });
};
