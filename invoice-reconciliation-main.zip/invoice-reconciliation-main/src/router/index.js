import { createRouter, createWebHistory } from "vue-router";

import Tasks from "../views/Tasks.vue";
import Timesheets from "../views/Timesheets.vue";
import Classes from "../views/Classes.vue";
import Reconciliation from "../views/Reconciliation.vue";
import InstructorEntries from "../views/InstructorEntries.vue";
import FineEntries from "../views/FineEntries.vue";
import Invoices from "../views/Invoices.vue";
import InvoicesReceived from "../views/InvoicesReceived.vue";
import AmountReceived from "../views/AmountReceived.vue";
import RemittancesSent from "../views/RemittancesSent.vue";
import Clients from "../views/Clients.vue";
import Dropdowns from "../views/Dropdowns.vue";
import Settings from "../views/Settings.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/tasks",
      name: "tasks",
      component: Tasks,
    },
    {
      path: "/timesheets",
      name: "timesheets",
      component: Timesheets,
    },
    {
      path: "/classes",
      name: "classes",
      component: Classes,
    },
    {
      path: "/reconciliation",
      name: "reconciliation",
      component: Reconciliation,
    },
    {
      path: "/instructorEntries",
      name: "instructorEntries",
      component: InstructorEntries,
    },
    {
      path: "/fineEntries",
      name: "fineEntries",
      component: FineEntries,
    },
    {
      path: "/invoices",
      name: "invoices",
      component: Invoices,
    },
    {
      path: "/invoicesReceived",
      name: "invoicesReceived",
      component: InvoicesReceived,
    },
    {
      path: "/amountReceived",
      name: "amountReceived",
      component: AmountReceived,
    },
    {
      path: "/remittancesSent",
      name: "remittancesSent",
      component: RemittancesSent,
    },
    {
      path: "/clients",
      name: "clients",
      component: Clients,
    },
    // {
    //   path: "/dropdowns/users",
    //   name: "dropdowns1",
    //   component: Dropdowns,
    // },
    // {
    //   path: "/dropdowns/managers",
    //   name: "dropdowns2",
    //   component: Dropdowns,
    // },
    // {
    //   path: "/dropdowns/taskTypes",
    //   name: "dropdowns3",
    //   component: Dropdowns,
    // },
    // {
    //   path: "/dropdowns/clientTypes",
    //   name: "dropdowns6",
    //   component: Dropdowns,
    // },

    // {
    //   path: "/dropdowns/activities",
    //   name: "dropdown4",
    //   component: Dropdowns,
    // },
    {
      path: "/dropdowns/gyms",
      name: "dropdowns1",
      component: Dropdowns,
    },
    {
      path: "/dropdowns/coaches",
      name: "dropdowns2",
      component: Dropdowns,
    },
    {
      path: "/dropdowns/classesTaught",
      name: "dropdowns3",
      component: Dropdowns,
    },
    {
      path: "/settings",
      name: "settings",
      component: Settings,
    },
  ],
});

export default router;
