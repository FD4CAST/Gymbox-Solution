//  All Schemas

//  Disable linting for this file
/* eslint-disable */
import { ElIcon } from "element-plus";
import { Timer } from "@element-plus/icons-vue";
import { driveImageURL, companyInfo } from "./helpers";

export const clientSchema = {
  sheetName: "Clients",
  title: "Clients",
  titleDetailView: "Client",
  defaultFormValues: {},
  fields: [
    {
      type: "input",
      inputType: "text",
      key: "firsrt_name",
      label: "First Name",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "text",
      key: "surname",
      label: "Surname",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "email",
      key: "email",
      label: "Email",
      placeholder: "Enter email",
      required: true,
    },

    {
      type: "input",
      inputType: "text",
      key: "status",
      label: "Status",
      placeholder: "Enter status",
      required: true,
    },
  ],
};
export const coachSchema = {
  sheetName: "Coaches",
  editPrevent: true,
  title: "Instructors",
  titleDetailView: "Instructor",
  defaultFormValues: {},
  fields: [
    {
      type: "input",
      inputType: "text",
      key: "name",
      label: "Name",
      colWidth: 160,
      placeholder: "",
      required: true,
      sort: {
        order: 1,
      },
    },
    {
      type: "input",
      inputType: "email",
      key: "email",
      label: "Email",
      colWidth: 200,
      placeholder: "Enter email",
      required: true,
    },
    {
      type: "input",
      inputType: "phone",
      key: "phone",
      label: "WhatsApp No (12 digit)",
      colWidth: 160,
      placeholder: "Enter 12 digit phone number",
      required: false,
    },

    // Rates for 30,45,90,120 mins
    {
      type: "number",
      inputType: "number",
      key: "30",
      label: "Rate (30 mins)",
      min: 0,
      max: 100,
      default: 15,
      colWidth: 70,
      placeholder: "",
      required: true,
    },
    {
      type: "number",
      inputType: "number",
      key: "45",
      label: "Rate (45 mins)",
      default: 20,
      min: 0,
      max: 100,
      colWidth: 70,
      placeholder: "",
      required: true,
    },
    {
      type: "number",
      inputType: "number",
      key: "60",
      label: "Rate (60 mins)",
      default: 30,
      min: 0,
      max: 100,
      colWidth: 70,
      placeholder: "",
      required: true,
    },
    {
      type: "number",
      inputType: "number",
      key: "90",
      label: "Rate (90 mins)",
      default: 45,
      min: 0,
      max: 100,
      colWidth: 70,
      placeholder: "",
      required: true,
    },
    {
      type: "number",
      inputType: "number",
      key: "120",
      label: "Rate (120 mins)",
      default: 55,
      min: 0,
      max: 100,
      colWidth: 70,
      placeholder: "",
      required: false,
    },
    {
      type: "input",
      inputType: "text",
      key: "pin",
      label: "PIN",
      colWidth: 70,
      placeholder: "",
      default: () => {
        // generate 4 digit pin
        return Math.floor(1000 + Math.random() * 9000);
      },
      cellRenderer: ({ cellData: val }) => {
        // const { scriptURL } = appStore;
        return val;
      },
      required: true,
    },
    {
      type: "input",
      inputType: "text",
      key: "account",
      label: "Bank Acc",
      colWidth: 70,
      placeholder: "",
      required: false,
    },
    {
      type: "input",
      inputType: "text",
      key: "sortCode",
      label: "Sort Code",
      colWidth: 70,
      placeholder: "",
      required: false,
    },
    {
      type: "select",
      inputType: "select",
      key: "type",
      label: "Type",
      options: ["Full Time", "Cover"],
      colWidth: 100,
      default: "Full Time",
      placeholder: "",
      required: true,
    },
    {
      type: "select",
      inputType: "select",
      key: "status",
      label: "Status",
      options: ["Active", "Inactive"],
      colWidth: 70,
      default: "Active",
      placeholder: "",
      required: true,
    },
  ],
  actionButtons: [
    {
      action: "openWhatsappweb",
      label: "Send WhatsApp",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "sendInvoiceRequestEmail",
      label: "Request Invoice by Email",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "sendAccessURL",
      label: "Send Access URL",
      actionType: "",
      icon: "",
      cls: "",
      type: "",
    },
  ],
  fab: [
    {
      action: "sendInvoiceRequestEmails",
      label: "Request Invoice by Email",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "sendInvoiceRequestWhatsApp",
      label: "Request Invoice by WhatsApp",
      icon: "",
      cls: "",
      type: "",
    },
  ],
};
export const gymSchema = {
  sheetName: "Gyms",
  fullscreen: false,
  title: "Gyms",
  titleDetailView: "Gym",

  tableWidth: 1200,
  defaultFormValues: {},
  fields: [
    {
      type: "input",
      inputType: "text",
      key: "name",
      label: "Name",
      colWidth: 180,
      placeholder: "",
      required: true,
      sort: {
        order: 1,
      },
    },
    {
      type: "input",
      inputType: "email",
      key: "email",
      colWidth: 200,
      label: "Primary Email",
      placeholder: "Enter email",
      required: true,
    },
    {
      type: "input",
      inputType: "textarea",
      key: "contacts",
      colWidth: 200,
      label: "Contact",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "textarea",
      key: "address",
      colWidth: 280,
      label: "Address",
      placeholder: "",
      required: true,
    },
    // {
    //   type: "groups",
    //   label: "Instructors",
    //   key: "coaches",
    //   colWidth: 100,
    //   fields: [
    //     {
    //       type: "select_server",
    //       inputType: "text",
    //       key: "coach",
    //       label: "Instructor",
    //       optionConfig: {
    //         value: "id",
    //         label: "name",
    //         source: "Coaches",
    //       },
    //       addMore: {
    //         sheetName: "Coaches",
    //         type: "inline",
    //       },
    //       placeholder: "",
    //       required: true,
    //       span: 8,
    //     },
    //   ],
    // },
  ],
};
export const classTaught = {
  sheetName: "Classes Taught",
  title: "Classes",
  tableWidth: 600,
  titleDetailView: "Class",
  defaultFormValues: {},
  fields: [
    {
      type: "input",
      inputType: "text",
      key: "name",
      label: "Name",
      placeholder: "",
      required: true,
      sort: {
        order: 1,
      },
    },
  ],
};
export const invoiceReceivedSchema = {
  sheetName: "Invoices Received",
  title: "Invoices Received",
  titleDetailView: "Invoice",
  defaultFormValues: {},
  fields: [
    {
      type: "select_server",
      inputType: "text",
      key: "coach",
      label: "Instructor",
      colWidth: 160,
      optionConfig: {
        value: "id",
        label: "name",
        source: "Coaches",
      },
      addMore: {
        sheetName: "Coaches",
        type: "inline",
      },
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "month",
      inputType: "month",
      key: "month",
      label: "For Month",
      colWidth: 100,
      placeholder: "",
      sort: true,
      required: true,
      cellRenderer: ({ cellData: val }) => {
        const formattedDate = new Date(val).toLocaleDateString("en-GB", {
          month: "long",
          year: "numeric",
        });
        return (
          <span class="flex items-center">
            <ElTag type="success">{formattedDate}</ElTag>
          </span>
        );
      },
      span: 4,
    },
    {
      type: "date",
      inputType: "date",
      key: "date",
      label: "Invoice Date",
      colWidth: 150,
      placeholder: "",
      required: true,
      cellRenderer: ({ cellData: val }) => {
        const formattedDate = new Date(val).toLocaleDateString("en-GB", {
          month: "long",
          day: "numeric",
          year: "numeric",
        });
        return (
          <span class="flex items-center">
            <ElTag type="success">{formattedDate}</ElTag>
          </span>
        );
      },
      span: 4,
    },
    // Fields for Invoice Number, Amount,status, comments
    {
      type: "input",
      inputType: "text",
      key: "invoiceNumber",
      label: "Invoice Number",
      colWidth: 120,
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "number",
      inputType: "number",
      key: "amount",
      label: "Amount",
      colWidth: 100,
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "files",
      inputType: "upload",
      key: "attachments",
      label: "Invoice Attachments",
      placeholder: "Upload Attachments",
      required: false,
    },
    {
      type: "select",
      inputType: "select",
      key: "status",
      label: "Status",
      default: "Under Approval",
      options: ["Under Approval", "Approved", "Paid"],
      colWidth: 100,
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "input",
      inputType: "textarea",
      key: "comments",
      label: "Comments",
      colWidth: 160,
      placeholder: "",
      required: true,
      span: 4,
    },
  ],
};

export const classSchema = {
  sheetName: "Classes",
  title: "Classes",
  tableWidth: 600,
  fullscreen: false,
  fullscreen: true,
  duplicateButton: false,
  defaultFormValues: {},
  fields: [
    {
      type: "date",
      inputType: "month",
      key: "date",
      label: "Date",
      placeholder: "Select date",
      cellRenderer: ({ cellData: val }) => {
        // Format to like March-24
        return new Date(val).toLocaleDateString("en-GB", {
          month: "long",
          year: "numeric",
        });
      },
      required: true,
    },
    {
      type: "groups",
      label: "Classes",
      key: "cls",
      fields: [
        {
          type: "date",
          inputType: "date",
          key: "date",
          label: "Date",
          placeholder: "Select date",
          required: true,
          cellRenderer: ({ cellData: val }) =>
            new Date(val).toLocaleDateString(),
          span: 4,
        },
        {
          type: "select_server",
          inputType: "text",
          key: "clTaught",
          label: "Class Taught",
          optionConfig: {
            value: "id",
            label: "name",
            source: "Classes Taught",
          },
          addMore: {
            sheetName: "Classes Taught",
            type: "inline",
          },
          placeholder: "",
          required: true,
          span: 4,
        },
        {
          type: "select_server",
          inputType: "text",
          key: "coach",
          label: "Instructor",
          optionConfig: {
            value: "id",
            label: "first_name",
            source: "Coaches",
          },
          addMore: {
            sheetName: "Coaches",
            type: "inline",
          },
          placeholder: "",
          required: true,
          span: 4,
        },
        {
          type: "select_server",
          inputType: "text",
          key: "coveredFor",
          label: "Covered For",
          optionConfig: {
            value: "id",
            label: "first_name",
            source: "Coaches",
          },
          addMore: {
            sheetName: "Coaches",
            type: "inline",
          },
          placeholder: "",
          required: false,
          span: 4,
        },
        {
          type: "time",
          inputType: "text",
          key: "time",
          label: "Time",
          placeholder: "Select time",
          required: true,
          span: 4,
        },
        // {
        //   type: "number",
        //   inputType: "number",
        //   key: "minutes",
        //   label: "Minutes",
        //   max: 59,
        //   min: 0,
        //   default: 0,
        //   placeholder: "Enter hours",
        //   onChange: {
        //     fn: (form) => form.hours * form.rate + (form.minutes * form.rate) / 60,
        //     targetField: "amount",
        //   },
        //   required: true,
        // },
        {
          type: "number",
          inputType: "number",
          step: 0.01,
          key: "duration",
          label: "Duration",
          placeholder: "",
          disabled: false,
          required: true,
          span: 2,
        },
      ],
    },

    {
      type: "input",
      inputType: "text",
      key: "description",
      label: "Description",
      placeholder: "Enter description",
      required: true,
    },
  ],
  actionButtons: [
    {
      action: "requestReview",
      label: "Request Review",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "generateInvoice",
      label: "Generate Invoice",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "sendWhatsApp",
      label: "Send WhatsApp",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "sendEmail",
      label: "Send Email",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "lock",
      label: "Lock",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "unlock",
      label: "Un-Lock",
      icon: "",
      cls: "",
      type: "",
    },
  ],
};
export const instructorLogSchema = {
  sheetName: "Instructor Entries",
  title: "Instructor Entries",
  titleDetailView: "Instructor Entries",
  fullscreen: false,
  duplicateButton: false,
  defaultFormValues: {},
  defaultSort: {
    key: "date",
    order: "desc",
  },
  fields: [
    {
      type: "datetime",
      inputType: "datetime",
      key: "date",
      label: "Date & Time",
      colWidth: 240,
      placeholder: "Select date & time",
      required: true,
      sort: {
        order: 1,
      },
      cellRenderer: ({ cellData: val }) => {
        const weeks = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        const week = weeks[new Date(val).getDay()];
        const formattedDate = new Date(val).toLocaleDateString("en-GB", {
          month: "long",
          day: "numeric",
          year: "numeric",
          hour: "numeric",
          minute: "numeric",
          hour12: false,
        });
        return (
          <span class="flex items-center">
            <ElTag type="success">{week}</ElTag>
            {formattedDate}
          </span>
        );
      },
      span: 4,
    },
    {
      type: "select_server",
      inputType: "text",
      key: "gym",
      label: "Gym",
      colWidth: 160,
      optionConfig: {
        value: "id",
        label: "name",
        source: "Gyms",
      },
      addMore: {
        sheetName: "Gyms",
        type: "inline",
      },
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "select_server",
      inputType: "text",
      key: "clTaught",
      label: "Class",
      optionConfig: {
        value: "id",
        label: "name",
        source: "Classes Taught",
      },
      addMore: {
        sheetName: "Classes Taught",
        type: "inline",
      },
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "select_server",
      inputType: "text",
      key: "coach",
      label: "Instructor",
      colWidth: 180,
      optionConfig: {
        value: "id",
        label: "name",
        source: "Coaches",
      },
      addMore: {
        sheetName: "Coaches",
        type: "inline",
      },
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "select_server",
      inputType: "text",
      key: "coveredFor",
      label: "Covered For",
      colWidth: 300,
      optionConfig: {
        value: "id",
        label: "name",
        source: "Covers",
      },
      addMore: {
        sheetName: "Covers",
        type: "inline",
      },
      placeholder: "",
      required: false,
      span: 4,
    },
    // {
    //   type: "time",
    //   inputType: "text",
    //   key: "time",
    //   label: "Time",
    //   placeholder: "Select time",
    //   required: true,
    //   span: 4,
    // },
    // {
    //   type: "number",
    //   inputType: "number",
    //   key: "minutes",
    //   label: "Minutes",
    //   max: 59,
    //   min: 0,
    //   default: 0,
    //   placeholder: "Enter hours",
    //   onChange: {
    //     fn: (form) => form.hours * form.rate + (form.minutes * form.rate) / 60,
    //     targetField: "amount",
    //   },
    //   required: true,
    // },
    {
      type: "select",
      inputType: "number",
      step: 0.01,
      key: "duration",
      colWidth: 100,
      label: "Duration (mins)",
      options: [30, 45, 60, 90, 120],
      default: 60,
      cellRenderer: ({ cellData: val }) => {
        return val + " mins";
      },
      append: "mins",
      placeholder: "",
      disabled: false,
      required: true,
      span: 2,
    },
  ],
  // actionButtons: [
  //   {
  //     action: "requestReview",
  //     label: "Request Review",
  //     icon: "",
  //     cls: "",
  //     type: "",
  //   },
  //   {
  //     action: "lock",
  //     label: "Lock",
  //     icon: "",
  //     cls: "",
  //     type: "",
  //   },
  //   {
  //     action: "unlock",
  //     label: "Un-Lock",
  //     icon: "",
  //     cls: "",
  //     type: "",
  //   },
  // ],
  fab: [
    {
      action: "duplicatePreviousWeekSchedule",
      label: "Duplicate Previous Week Schedule",
      icon: "",
      cls: "",
      type: "",
    },
  ],
};
export const fineSchema = {
  sheetName: "Fine Entries",
  title: "Fine Entries",
  titleDetailView: "Fine Entry",
  fullscreen: false,
  duplicateButton: false,
  defaultFormValues: {},
  defaultSort: {
    key: "date",
    order: "desc",
  },
  fields: [
    {
      type: "datetime",
      inputType: "datetime",
      key: "date",
      label: "Date & Time",
      colWidth: 210,
      sort: true,
      placeholder: "Select date & time",
      required: true,
      cellRenderer: ({ cellData: val }) => {
        const weeks = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        const week = weeks[new Date(val).getDay()];
        const formattedDate = new Date(val).toLocaleDateString("en-GB", {
          month: "long",
          day: "numeric",
          year: "numeric",
          hour: "numeric",
          minute: "numeric",
        });
        return (
          <span class="flex items-center">
            <ElTag type="success">{week}</ElTag>
            {formattedDate}
          </span>
        );
      },
      span: 4,
    },
    {
      type: "select_server",
      inputType: "text",
      key: "gym",
      label: "Gym",
      colWidth: 160,
      optionConfig: {
        value: "id",
        label: "name",
        source: "Gyms",
      },
      addMore: {
        sheetName: "Gyms",
        type: "inline",
      },
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "select_server",
      inputType: "text",
      key: "clTaught",
      label: "Fined for Class",
      optionConfig: {
        value: "id",
        label: "name",
        source: "Classes Taught",
      },
      addMore: {
        sheetName: "Classes Taught",
        type: "inline",
      },
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "select_server",
      inputType: "text",
      key: "coach",
      label: "Fined Instructor",
      colWidth: 160,
      optionConfig: {
        value: "id",
        label: "name",
        source: "Coaches",
      },
      addMore: {
        sheetName: "Coaches",
        type: "inline",
      },
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "select",
      inputType: "number",
      step: 0.01,
      key: "duration",
      label: "Missed Duration (mins)",
      options: [30, 45, 60, 90, 120],
      default: 60,
      colWidth: 140,
      cellRenderer: ({ cellData: val }) => {
        return val + " mins";
      },
      append: "mins",
      placeholder: "",
      disabled: false,
      required: true,
      span: 2,
    },
    {
      type: "number",
      inputType: "number",
      step: 0.01,
      key: "fine",
      colWidth: 100,
      label: "Fine Amount",
      placeholder: "",
      required: true,
      span: 2,
    },
  ],
  // actionButtons: [
  //   {
  //     action: "requestReview",
  //     label: "Request Review",
  //     icon: "",
  //     cls: "",
  //     type: "",
  //   },
  //   {
  //     action: "lock",
  //     label: "Lock",
  //     icon: "",
  //     cls: "",
  //     type: "",
  //   },
  //   {
  //     action: "unlock",
  //     label: "Un-Lock",
  //     icon: "",
  //     cls: "",
  //     type: "",
  //   },
  // ],
};

export const remittanceSchema = {
  sheetName: "Remittances Sent",
  title: "Remittance Record",
  fullscreen: false,

  duplicateButton: false,
  defaultFormValues: {},
  defaultSort: {
    key: "month",
    order: "desc",
  },
  fields: [
    {
      type: "month",
      inputType: "month",
      key: "month",
      label: "For Month",
      colWidth: 100,
      placeholder: "",
      sort: true,
      required: true,
      cellRenderer: ({ cellData: val }) => {
        const formattedDate = new Date(val).toLocaleDateString("en-GB", {
          month: "long",
          year: "numeric",
        });
        return (
          <span class="flex items-center">
            <ElTag type="success">{formattedDate}</ElTag>
          </span>
        );
      },
      span: 4,
    },
    {
      type: "select_server",
      inputType: "text",
      key: "coach",
      label: "Instructor",
      colWidth: 200,
      optionConfig: {
        value: "id",
        label: "name",
        source: "Coaches",
      },
      addMore: {
        sheetName: "Coaches",
        type: "inline",
      },
      placeholder: "",
      required: true,
      span: 4,
    },
    // {
    //   type: "number",
    //   inputType: "currency",
    //   step: 0.01,
    //   key: "amount",
    //   label: "Amount",
    //   placeholder: "",
    //   required: true,
    //   span: 2,
    // },
    {
      type: "input",
      inputType: "text",
      key: "fileId",
      label: "Remittance Advice",
      colWidth: 200,
      placeholder: "",
      required: false,
      span: 4,
      cellRenderer: ({ cellData: val }) => {
        return (
          <a href={driveImageURL(val)} target="_blank">
            <ElTag type="success">View Remittance Advice</ElTag>
          </a>
        );
      },
    },
    // Statuse timeline
    {
      type: "select",
      inputType: "select",
      key: "status",
      label: "Status",
      options: ["Pending", "Generated", "Sent", "Paid"],
      colWidth: 150,
      placeholder: "",
      required: true,
      cellRenderer: ({ cellData: val }) => {
        let color = "info";
        switch (val) {
          case "Uninvoiced":
            color = "warning";
            break;
          case "Invoiced":
            color = "info";
            break;
          case "Sent":
            color = "success";
            break;
          case "Paid":
            color = "primary";
            break;
          default:
            color = "info";
        }
        return <ElTag type={color}>{val}</ElTag>;
      },
      span: 4,
    },
  ],
};
export const amountReceivedSchema = {
  sheetName: "Amount Received",
  title: "Amount Received",
  fullscreen: false,

  duplicateButton: false,
  defaultFormValues: {},
  defaultSort: {
    key: "month",
    order: "desc",
  },
  fields: [
    {
      type: "month",
      inputType: "month",
      key: "month",
      label: "For Month",
      colWidth: 100,
      placeholder: "",
      required: true,
      sort: true,
      cellRenderer: ({ cellData: val }) => {
        if (!val) return "";
        const formattedDate = new Date(val).toLocaleDateString("en-GB", {
          month: "long",
          year: "numeric",
        });
        return (
          <span class="flex items-center">
            <ElTag type="success">{formattedDate}</ElTag>
          </span>
        );
      },
      span: 4,
    },
    // Invoice Number
    {
      type: "number",
      inputType: "number",
      key: "invoiceNumber",
      label: "Invoice No.",
      min: 0,
      colWidth: 90,
      placeholder: "",
      cellRenderer: ({ cellData: val }) => {
        return companyInfo.invoicePrefix + val.toString().padStart(3, "0");
      },
      required: true,
      span: 4,
    },
    {
      type: "select_server",
      inputType: "text",
      key: "gym",
      label: "Gym",
      colWidth: 200,
      optionConfig: {
        value: "id",
        label: "name",
        source: "Gyms",
      },
      addMore: {
        sheetName: "Gyms",
        type: "inline",
      },
      placeholder: "",
      required: true,
      span: 4,
    },
    {
      type: "date",
      inputType: "date",
      key: "date",
      label: "Received Date",
      colWidth: 150,
      placeholder: "",
      required: false,
      cellRenderer: ({ cellData: val }) => {
        if (!val) return "";
        const formattedDate = new Date(val).toLocaleDateString("en-GB", {
          month: "long",
          day: "numeric",
          year: "numeric",
        });
        return (
          <span class="flex items-center">
            <ElTag type="success">{formattedDate}</ElTag>
          </span>
        );
      },
      span: 4,
    },

    {
      type: "number",
      inputType: "number",
      step: 0.01,
      key: "amount",
      label: "Received Amount",
      placeholder: "",
      required: false,
      span: 2,
    },
    {
      type: "input",
      inputType: "text",
      key: "fileId",
      label: "Invoice PDF",
      colWidth: 100,
      placeholder: "",
      required: false,
      span: 4,
      cellRenderer: ({ cellData: val }) => {
        return (
          <a href={driveImageURL(val)} target="_blank">
            <ElTag type="success">View Invoice</ElTag>
          </a>
        );
      },
    },
    // Ref No:
    {
      type: "input",
      inputType: "text",
      key: "refNo",
      label: "Ref No",
      colWidth: 150,
      placeholder: "",
      required: false,
      span: 4,
    },
    //  Status select , options :- Uninvoiced,Invoiced, Invoice Sent, Amount Received
    {
      type: "select",
      inputType: "select",
      key: "status",
      label: "Status",
      options: ["Uninvoiced", "Invoiced", "Invoice Sent", "Amount Received"],
      colWidth: 150,
      placeholder: "",
      required: true,
      cellRenderer: ({ cellData: val }) => {
        let color = "info";
        switch (val) {
          case "Uninvoiced":
            color = "warning";
            break;
          case "Invoiced":
            color = "info";
            break;
          case "Invoice Sent":
            color = "success";
            break;
          case "Amount Received":
            color = "primary";
            break;
          default:
            color = "info";
        }
        return <ElTag type={color}>{val}</ElTag>;
      },
      span: 4,
    },
  ],
  // actionButtons: [
  //   {
  //     action: "requestReview",
  //     label: "Request Review",
  //     icon: "",
  //     cls: "",
  //     type: "",
  //   },
  //   {
  //     action: "lock",
  //     label: "Lock",
  //     icon: "",
  //     cls: "",
  //     type: "",
  //   },
  //   {
  //     action: "unlock",
  //     label: "Un-Lock",
  //     icon: "",
  //     cls: "",
  //     type: "",
  //   },
  // ],
};
export const invoicechema = {
  sheetName: "Invoices",
  fullscreen: true,
  title: "Invoices Sent",
  duplicateButton: false,
  removeBtnClicked: {
    fn: (form) => {
      const entries = form.cls;
      let amount = 0;
      entries.forEach((entry) => {
        amount += entry.duration * entry.rate;
      });
      const total = amount + (amount * form.vat) / 100;
      return [amount, total];
    },
    targetField: ["amount", "total"],
  },
  defaultFormValues: {},
  fields: [
    {
      type: "date",
      inputType: "date",
      key: "date",
      label: "Date",
      placeholder: "Select date",
      cellRenderer: ({ cellData: val }) => {
        return new Date(val).toLocaleDateString("en-GB", {
          month: "long",
          day: "numeric",
          year: "numeric",
        });
      },
      required: true,
    },
    {
      type: "groups",
      label: "Classes",
      key: "cls",
      fields: [
        {
          type: "date",
          inputType: "date",
          key: "date",
          label: "Date",
          placeholder: "Select date",
          required: true,
          cellRenderer: ({ cellData: val }) =>
            new Date(val).toLocaleDateString(),
          span: 4,
        },
        {
          type: "select_server",
          inputType: "text",
          key: "coach",
          label: "Instructor",
          optionConfig: {
            value: "id",
            label: "name",
            source: "Coaches",
          },
          addMore: {
            sheetName: "Coaches",
            type: "inline",
          },
          placeholder: "",
          required: true,
          span: 8,
        },
        // {
        //   type: "select_server",
        //   inputType: "text",
        //   key: "coveredFor",
        //   label: "Covered For",
        //   optionConfig: {
        //     value: "id",
        //     label: "first_name",
        //     source: "Coaches",
        //   },
        //   addMore: {
        //     sheetName: "Coaches",
        //     type: "inline",
        //   },
        //   placeholder: "",
        //   required: false,
        //   span:4,
        // },
        // {
        //   type: "time",
        //   inputType: "text",
        //   key: "time",
        //   label: "Time",
        //   placeholder: "Select time",
        //   required: true,
        //   span:4,
        // },

        {
          type: "number",
          inputType: "currency",
          step: 0.01,
          key: "duration",
          label: "Duration",
          placeholder: "",
          onChange: {
            fn: (form) => {
              const entries = form.cls;
              let amount = 0;
              entries.forEach((entry) => {
                amount += entry.duration * entry.rate;
              });
              const total = amount + (amount * form.vat) / 100;
              return [amount, total];
            },
            targetField: ["amount", "total"],
          },
          disabled: false,
          required: true,
          span: 2,
        },
        {
          type: "number",
          inputType: "currency",
          step: 0.01,
          key: "rate",
          label: "Rate",
          placeholder: "",
          onChange: {
            fn: (form) => {
              const entries = form.cls;
              let amount = 0;
              entries.forEach((entry) => {
                amount += entry.duration * entry.rate;
              });
              const total = amount + (amount * form.vat) / 100;
              return [amount, total];
            },
            targetField: ["amount", "total"],
          },
          disabled: false,
          required: true,
          span: 2,
        },
      ],
    },
    // {
    //   type: "input",
    //   inputType: "text",
    //   key: "description",
    //   label: "Description",
    //   placeholder: "Enter description",
    //   required: true,
    // },
    {
      type: "number",
      inputType: "currency",
      key: "amount",
      label: "Amount",
      cellRenderer: ({ cellData: val }) => {
        return new Intl.NumberFormat("en-GB", {
          style: "currency",
          currency: "GBP",
        }).format(val);
      },
      default: 0,
      placeholder: "",
      required: false,
      disabled: true,
    },
    {
      type: "number",
      inputType: "number",
      key: "vat",
      label: "VAT (%)",
      cellRenderer: ({ cellData: val }) => {
        return val + "%";
      },
      default: 20,
      placeholder: "",
      required: false,
      disabled: true,
    },
    {
      type: "number",
      inputType: "number",
      key: "total",
      label: "Total",
      default: 0,
      cellRenderer: ({ cellData: val }) => {
        return new Intl.NumberFormat("en-GB", {
          style: "currency",
          currency: "GBP",
        }).format(val);
      },
      placeholder: "",
      required: false,
      disabled: true,
    },
    {
      type: "timeline",
      inputType: "timeline",
      key: "status",
      label: "Status",
      hidden: true,
      default: () => {
        return [
          {
            mailSent: false,
            on: null,
          },
          {
            paymentReceived: false,
            on: null,
            amontReceived: 0,
          },
        ];
      },
    },
  ],
  // actionButtons for :-Generate Invoice,Preview Invoice, Send Invoice, Mark Paid
  actionButtons: [
    {
      action: "generateInvoice",
      label: "Generate Invoice",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "sendInvoice",
      label: "Send Invoice",
      icon: "",
      cls: "",
      type: "",
    },
    {
      action: "markPaid",
      label: "Mark Paid",
      icon: "",
      cls: "",
      type: "",
    },
  ],
};

export const comapanyInfoSchema = {
  sheetName: "Company Information",
  title: "Company Information",
  fullscreen: false,
  defaultFormValues: {},
  fields: [
    {
      type: "input",
      inputType: "text",
      key: "companyName",
      label: "Company Name",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "text",
      key: "address1",
      label: "Address Line 1",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "text",
      key: "address2",
      label: "Address Line 2",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "text",
      key: "city",
      label: "City",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "text",
      key: "postcode",
      label: "Postcode",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "text",
      key: "phone",
      label: "Phone",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "email",
      key: "email",
      label: "Email",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "text",
      key: "vatNumber",
      label: "VAT Number",
      placeholder: "",
      required: true,
    },
    {
      type: "input",
      inputType: "text",
      key: "bankDetails",
      label: "Bank Details",
      placeholder: "",
      required: true,
    },
  ],
};

export const allSchemas = [
  gymSchema,
  coachSchema,
  classSchema,
  classTaught,
  invoicechema,
  instructorLogSchema,
  fineSchema,
  invoiceReceivedSchema,
  amountReceivedSchema,
  remittanceSchema,
];

export const allSheetNames = allSchemas.map((schema) => schema.sheetName);
export const getModel = (fields) => {
  return fields.reduce((acc, field) => {
    switch (field.type) {
      case "number":
        acc[field.key] = field.default || null;
        break;
      case "date":
        acc[field.key] = field.default || new Date();
        break;
      case "select":
        acc[field.key] = field.default || "";
      case "files":
        acc[field.key] = field.default || [];
        break;
      case "groups":
        acc[field.key] = [getModel(field.fields)];
        break;
      default:
        if (typeof field.default === "function") {
          acc[field.key] = field.default();
        } else {
          acc[field.key] = field.default || "";
        }
        break;
    }
    return acc;
  }, {});
};

export const menuSchema = [
  { title: "Classes", path: "/classes", hidden: false },
  { title: "Reconciliation", path: "/reconciliation", hidden: true },
  { title: "Instructor Entries", path: "/instructorEntries", hidden: false },
  { title: "Fine Entries", path: "/fineEntries", hidden: true },
  {
    title: "Invoices",
    hidden: true,
    menus: [
      { title: "Custom Invoices Sent", path: "/invoices", hidden: true },
      { title: "Invoices Received", path: "/invoicesReceived", hidden: true },
      { title: "Invoices Sent", path: "/amountReceived", hidden: true },
      { title: "Remittances Sent", path: "/remittancesSent", hidden: true },
    ],
  },
  {
    title: "Configuration",
    hidden: false,
    menus: [
      { title: "Gyms", path: "/dropdowns/gyms", hidden: true },
      { title: "Instructors", path: "/dropdowns/coaches", hidden: false },
      { title: "Classes", path: "/dropdowns/classesTaught", hidden: true },
    ],
  },
  // { title: "Company Profile", path: "/settings" },
  { title: "Advanced", path: "/settings", hidden: true },
];
