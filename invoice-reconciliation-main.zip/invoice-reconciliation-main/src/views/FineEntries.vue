<script setup lang="jsx">
import SmartTable from '~/components/SmartTable.vue'

</script>
<template>
  <main>
    <div>
      <SmartTable />
    </div>
  </main>
</template>
