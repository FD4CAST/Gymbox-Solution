<template>
  <div class="px-4">
    <el-space>
      <el-form-item label="Select Gym:" style="width:400px;">
        <el-select v-model="gymId" placeholder="" clearable size="small">
          <el-option v-for="(item, index) in  tables['Gyms'] " :key="index" :label="item['name']"
            :value="item['id']"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item style="width:400px;margin-left: 40px;" label="Selected Week:">
        <el-tag style="padding:10px;">
          {{ currentDateRange }}
        </el-tag>
      </el-form-item>
      <el-form-item style="width:400px;margin-left: 60px;" label="Logged In Instructor:" v-if="loggedInstructorName">
        <el-tag style="padding:10px;">
          <pre>{{ loggedInstructorName }}</pre>
        </el-tag>
      </el-form-item>
    </el-space>

    <div>

    </div>
    <div class="mx-2">
      <Qalendar :events="events" :config="config" :selected-date="new Date()" @updated-period="dateChanged" />
    </div>
  </div>
</template>

<script setup>
import { Qalendar } from "qalendar";
import { useAppStore } from "~/stores/appStore";
import { formatDateString, getDatesOfCurrentWeek, formatDateWithOrdinalSuffix } from "~/helpers";


const gymId = ref(null);

const currentDateRange = ref("");
const appStore = useAppStore();
const { tables, indexedTables, chooseAndRunAction, sort, loggedInstructorName } =
  appStore;
// console.log(indexedTables);
const tbl = tables['Instructor Entries'];
const dd = indexedTables;

currentDateRange.value = `${formatDateWithOrdinalSuffix(new Date(getDatesOfCurrentWeek()[0]))} - ${formatDateWithOrdinalSuffix(new Date(getDatesOfCurrentWeek()[1]))}`;
const dateChanged = (date) => {
  currentDateRange.value = `${formatDateWithOrdinalSuffix(date.start)} - ${formatDateWithOrdinalSuffix(
    date.end
  )}`;
};

let events = computed(() => {
  let filteredTable = tbl;
  if (gymId.value) {
    filteredTable = tbl.filter(({ form }) => form.gym == gymId.value);
  }

  return filteredTable.map(({ id, form }) => {
    const { clTaught, date, duration, coveredFor, gym, coach } = form;
    const start = new Date(date);
    const end = new Date(date);
    const coveredForName = coveredFor ? ` (Covered for ${dd['Coaches'][coveredFor]?.name})` : "";
    const gymName = dd['Gyms'][gym]?.name;
    end.setMinutes(end.getMinutes() + duration);
    let event = {
      title: gymName + " | " + dd['Classes Taught'][clTaught]?.name,
      with: dd['Coaches'][coach]?.name + coveredForName,
      time: { start: formatDateString(start), end: formatDateString(end) },
      color: "blue",
      isEditable: true,
      id,
    };
    return event;
  });
});

const config = {
  dayBoundaries: {
    start: 6,
    end: 22,
  },
  // week: {
  //   startsOn: 'monday',
  //   nDays: 5,
  //   scrollToHour: 5,
  // },
  month: {
    showTrailingAndLeadingDates: false,
  },
  locale: 'en-GB',
  defaultMode: 'week',
  isSilent: true,
  showCurrentTime: true,
}

</script>

<style>
@import "qalendar/dist/style.css";
</style>