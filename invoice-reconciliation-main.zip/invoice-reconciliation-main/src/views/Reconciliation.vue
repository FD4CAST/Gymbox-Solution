<template>
  <div>
    <el-tabs v-model="activeTab" class="demo-tabs" @tab-click="handleTabChange">
      <el-tab-pane label="By Gym" name="second">
        <div class="container">
          <div class="month">
            <el-table border :data="monthKeys" highlight-current-row @current-change="handleMonthChange"
              :default-sort="{ prop: 'month', order: 'descending' }">
              <el-table-column prop="month" label="Month" width="180" :formatter="monthFormatter" />
            </el-table>
          </div>
          <div class="gym" v-if="gymKeys">
            <el-card class="stats-card">
              <el-row>
                <el-col :span="6" v-for="card in gymKeys.statsCard" :key="card.title">
                  <el-statistic :title="card.title" :value="card.value" precision="2" :formatter="currencyFormatter"
                    :value-style="{ color: '#3eaf7c' }">
                  </el-statistic>
                </el-col>
              </el-row>
            </el-card>
            <el-table :data="gymKeys.arr" highlight-current-row @current-change="handleGymChange" border
              @expand-change="rowExpandedInGymTbl" ref="tblByGym" v-loading="loading">
              <el-table-column type="expand">
                <template #default="props">
                  <div m="4">
                    <el-table :data="processEntries(props.row.entries, props.row.gym)" size="small" style="color:blue">
                      <el-table-column label="Instructor" prop="coach" width="250" :formatter="coachFormatter" />
                      <el-table-column label="30" width="50" prop="countOf30" />
                      <el-table-column label="45" width="50" prop="countOf45" />
                      <el-table-column label="60" width="50" prop="countOf60" />
                      <el-table-column label="90" width="50" prop="countOf90" />
                      <el-table-column label="120" width="50" prop="countOf120" />
                      <el-table-column label="Total" width="100" prop="total"
                        :formatter="({ total }) => currencyFormatter(total)" />
                      <el-table-column label="Fine" width="100" prop="fineAmount"
                        :formatter="({ fineAmount }) => currencyFormatter(fineAmount)" />
                      <el-table-column label="Total Pay" width="100" prop="totalAfterFine"
                        :formatter="({ totalAfterFine }) => currencyFormatter(totalAfterFine)" />
                    </el-table>
                    <el-space class="m-2">
                      <el-button type="primary" v-if="!selectedInvoiceRow" @click="generateInvoice(props.row.gym)"
                        size="small">
                        Generate Invoice</el-button>
                      <el-button type="primary" v-if="selectedInvoiceRow" @click="sendInvoice(selectedInvoiceRow)">Send
                        Invoice</el-button>
                      <el-tag v-if="selectedInvoiceRow">
                        Status:{{ selectedInvoiceRow.status }}
                      </el-tag>
                      <a :href="driveImageURL(selectedInvoiceRow.fileId)" target="_blank" v-if="selectedInvoiceRow">
                        <el-tag v-if="selectedInvoiceRow">
                          View Invoice
                        </el-tag>
                      </a>
                    </el-space>
                    <!-- <pre>
                      {{ selectedInvoiceRow }}
                    </pre> -->
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="gym" label="Gym" width="200" :formatter="gymFormatter" />
              <el-table-column prop="30" label="30" width="50" />
              <el-table-column prop="45" label="45" width="50" />
              <el-table-column prop="60" label="60" width="50" />
              <el-table-column prop="90" label="90" width="50" />
              <el-table-column prop="120" label="120" width="50" />
              <el-table-column prop="total" label="Total Pay" width="100"
                :formatter="({ total }) => currencyFormatter(total)" />
              <el-table-column prop="fineAmount" label="Fine" width="100"
                :formatter="({ fineAmount }) => currencyFormatter(fineAmount)" />
              <el-table-column prop="totalCost" label="Total Cost" width="100"
                :formatter="({ totalCost }) => currencyFormatter(totalCost)" />
              <el-table-column prop="grossSales" label="Gross Sales" width="100"
                :formatter="({ grossSales }) => currencyFormatter(grossSales)" />
              <el-table-column prop="VAT" label="VAT" width="100" :formatter="({ VAT }) => currencyFormatter(VAT)" />
              <el-table-column prop="sales" label="Sales" width="100"
                :formatter="({ sales }) => currencyFormatter(sales)" />
              <el-table-column prop="received" label="Received" width="100"
                :formatter="({ received }) => currencyFormatter(received)"
                :class-name="received > 0 ? 'amount-positive' : ''" />
              <el-table-column prop="profit" label="Profit" width="100"
                :formatter="({ profit }) => currencyFormatter(profit)" />

            </el-table>

          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="By Instructor" name="first">

        <div class="container">
          <div class="month">
            <el-table border :data="monthKeysCoachWise" highlight-current-row
              @current-change="handleMonthChangeCoachWise" :default-sort="{ prop: 'month', order: 'descending' }">
              <el-table-column prop="month" label="Month" width="180" :formatter="monthFormatter" />
            </el-table>
          </div>
          <div class="gym" v-if="coachKeys">
            <el-table :data="coachKeys" highlight-current-row @expand-change="rowExpandedInCoachTbl" ref="tblByCoach"
              border v-loading="loading">
              <el-table-column type="expand">
                <template #default="props">
                  <div m="4">
                    <el-table :data="processEntriesCoachWise(props.row.entries, props.row.coach)" size="small"
                      style="color:blue">
                      <el-table-column label="Gym" prop="gym" width="250" :formatter="gymFormatter" />
                      <el-table-column label="30" width="50" prop="countOf30" />
                      <el-table-column label="45" width="50" prop="countOf45" />
                      <el-table-column label="60" width="50" prop="countOf60" />
                      <el-table-column label="90" width="50" prop="countOf90" />
                      <el-table-column label="120" width="50" prop="countOf120" />
                      <el-table-column label="Total" width="100" prop="total"
                        :formatter="({ total }) => currencyFormatter(total)" />
                      <el-table-column label="Fine" width="100" prop="fineAmount"
                        :formatter="({ fineAmount }) => currencyFormatter(fineAmount)" />
                      <el-table-column label="Total Pay" width="100" prop="totalAfterFine"
                        :formatter="({ totalAfterFine }) => currencyFormatter(totalAfterFine)" />
                    </el-table>

                    <el-space class="m-2" v-if="expandedRows.length < 2">
                      <el-button type="primary" v-if="!selectedRemittanceRow" size="small" @click=" generateRemittance(processEntriesCoachWise(props.row.entries, props.row.coach),
      props.row.coach)">
                        Generate Remittance Advice</el-button>
                      <el-button type="primary" v-if="selectedRemittanceRow"
                        @click="sendRemittance(selectedRemittanceRow)">Send
                        Remittance Advice</el-button>
                      <el-tag v-if="selectedRemittanceRow">
                        Status:{{ selectedRemittanceRow.status }}
                      </el-tag>
                      <a :href="driveImageURL(selectedRemittanceRow.fileId)" target="_blank"
                        v-if="selectedRemittanceRow">
                        <el-tag v-if="selectedRemittanceRow">
                          View Remittance Advice
                        </el-tag>
                      </a>
                    </el-space>

                    <!-- <div>
                      <pre>
                        {{ selectedRemittanceRow }}
                      </pre>
                    </div> -->
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="coach" label="Instructor" width="200" :formatter="coachFormatter" />
              <el-table-column prop="30" label="30" width="50" />
              <el-table-column prop="45" label="45" width="50" />
              <el-table-column prop="60" label="60" width="50" />
              <el-table-column prop="90" label="90" width="50" />
              <el-table-column prop="120" label="120" width="50" />
              <el-table-column prop="total" label="Total" width="100"
                :formatter="({ total }) => currencyFormatter(total)" />
              <el-table-column prop="fineAmount" label="Fine" width="100"
                :formatter="({ fineAmount }) => currencyFormatter(fineAmount)" />
              <el-table-column prop="totalCost" label="Total Pay" width="100"
                :formatter="({ totalCost }) => currencyFormatter(totalCost)" />
              <el-table-column label="Invoice Status" width="140">
                <template #default="scope">
                  <el-tag size="small" :type="colorTypes[getInvoiceOfInstructor(scope.row.coach)]">
                    {{ getInvoiceOfInstructor(scope.row.coach) }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column label="Actions" width="80">
                <template #default="scope">
                  <a :href="`https://wa.me/${dd['Coaches'][scope.row.coach]['phone']}?text=Hi, Please send your invoice.`"
                    target="_blank" v-if="dd['Coaches'][scope.row.coach]['phone']">
                    <IconWhatsapp />
                  </a>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>
    <!-- Remittance Slip Modal -->
    <el-dialog title="" v-model="remittanceModal.dialogVisible">
      <template #header="{ close, titleId, titleClass }">
        <div class="my-header">
          <el-space>
            <span>Remittance Advice</span>
          </el-space>
          <!-- <h4 :id="titleId" :class="titleClass">Remittance Slip</h4> -->
          <!-- <el-button @click="remittanceModal.dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="">Save Invoice</el-button>
          <el-button type="danger" @click="close">
            <el-icon class="el-icon--left">
              <CircleCloseFilled />
            </el-icon>
            Close
          </el-button> -->
        </div>
      </template>
      <PdfModal :data="remittanceModal.selectedRemittance" @generated="() => remittanceModal.dialogVisible = false" />
    </el-dialog>
    <!-- Invoice Modal -->
    <el-dialog title="" v-model="invoiceModal.dialogVisible">
      <template #header="{ close, titleId, titleClass }">
        <div class="my-header">
          <el-space>
            <span>Invoice</span>
          </el-space>
          <!-- <el-button @click="invoiceModal.dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="">Send</el-button>
          <el-button type="danger" @click="close">
            <el-icon class="el-icon--left">
              <CircleCloseFilled />
            </el-icon>
            Close
          </el-button> -->
        </div>
      </template>
      <InvoicePdfModal :data="invoiceModal.selectedInvoice" @generated="() => invoiceModal.dialogVisible = false" />
    </el-dialog>
  </div>

</template>

<script setup>

import { useAppStore } from "~/stores/appStore";
import { formatDateString, gymBoxRates, toMonth, driveImageURL, colorTypes } from "~/helpers";
import { computed, getCurrentInstance } from 'vue';
import PdfModal from "~/components/PdfModal.vue";
import IconWhatsapp from "~/components/icons/IconWhatsapp.vue";


const activeTab = ref('second')
const gymId = ref(null);
const tblByCoach = ref(null);
const tblByGym = ref(null);
const expandedRows = ref([]);
const selectMonth = ref(null);
const selectedMonthCoachWise = ref(null);
const selectedGym = ref(null);
const selectedCoach = ref(null);
const remittanceModal = ref({
  dialogVisible: false,
  selectedRemittance: null
});
const invoiceModal = ref({
  dialogVisible: false,
  selectedInvoice: null
});
const appStore = useAppStore();
const { indexedTables, chooseAndRunAction, sort, selectRemittanceRow, selectInvoiceRow } =
  appStore;
const tables = appStore.tables;
const loading = computed(() => appStore.loading);
const selectedRemittanceRow = computed(() => appStore.selectedRemittanceRow);
const selectedInvoiceRow = computed(() => appStore.selectedInvoiceRow);

const dd = indexedTables;
const tbl = tables['Instructor Entries'].map(({ form }) => {
  // const dt = new Date(form.date);
  // dt.setDate(1);
  form.month = toMonth(form.date);
  const payRate = {};
  [30, 45, 60, 90, 120].forEach(d => {
    // form[`payRate${duration}`] = dd['Coaches'][form.coach][duration];
    payRate[d] = dd['Coaches'][form.coach][d];
    form[d] = 0;
  });
  switch (form.duration) {
    case 30:
      form[30]++;
      break;
    case 45:
      form[45]++;
      break;
    case 60:
      form[60]++;
      break;
    case 90:
      form[90]++;
      break;
    case 120:
      form[120]++;
      break;
  }
  const total = [30, 45, 60, 90, 120].reduce((acc, curr) => {
    return acc + form[curr] * payRate[curr];
  }, 0);
  form.total = total;
  return form;
});

const fineTable = tables['Fine Entries'].map(({ form }) => {
  form.month = toMonth(form.date);
  return form;
});

const remittancesTable = tables['Remittances Sent'].map((r) => {
  r.month = toMonth(r.form.month);
  return r;
});


const amountReceivedTable = reactive(tables['Amount Received'].map((r) => {
  r.month = toMonth(r.form.month);
  return r;
}));

const invoicesReceived = tables['Invoices Received'].map((r) => {
  r.month = toMonth(r.form.month);
  return r;
});

console.log("invoicesReceived", invoicesReceived);
const getInvoiceOfInstructor = (coach) => {
  return invoicesReceived.find(item => item.coach == coach && item.month == selectedMonthCoachWise.value.month)?.status || "Not Received";

};


const handleMonthChange = (month) => {
  selectMonth.value = month;
};

const handleMonthChangeCoachWise = (month) => {
  selectedMonthCoachWise.value = month;
};

const handleGymChange = (gym) => {
  selectedGym.value = gym;
};
// Whatsapp click to chat
// const sendWhatsApp = (phone) => {
//   const message = "HiPlease send your invoice";
//   window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
// };


const rowExpandedInCoachTbl = (row, rows) => {
  // console.log("rowExpanded", row);
  // console.log("rows", rows);
  expandedRows.value = rows;
  if (rows.length > 1) {
    tblByCoach.value.toggleRowExpansion(rows[0], false);
  }
};
const rowExpandedInGymTbl = (row, rows) => {
  // console.log("rowExpanded", row);
  // console.log("rows", rows);
  expandedRows.value = rows;
  if (rows.length > 1) {
    tblByGym.value.toggleRowExpansion(rows[0], false);
  }
};

const generateRemittance = (data, coach) => {
  const obj = {};
  remittanceModal.value.dialogVisible = true;
  obj.entries = data;
  obj.selectedCoach = dd['Coaches'][coach];
  obj.selectedMonth = selectedMonthCoachWise.value.month;
  remittanceModal.value.selectedRemittance = obj;
};

const generateInvoice = (gym) => {
  invoiceModal.value.dialogVisible = true;
  const data = {};
  data.entries = tbl.filter(item => item.month == selectMonth.value.month && item.gym == gym);
  data.fineEntries = fineTable.filter(item => item.month == selectMonth.value.month && item.gym == gym);
  data.selectedGym = dd['Gyms'][gym];
  data.selectedMonth = selectMonth.value.month;
  invoiceModal.value.selectedInvoice = data;
};

const sendInvoice = (o) => {
  console.log("sendInvoice:-", o);
  const invoiceSendingPayload = {
    form: o.form,
    sheetName: "Amount Received",
    id: o.id || null,
    action: 'sendInvoice',
    selectedGym: dd['Gyms'][o.form.gym]
  };
  chooseAndRunAction('Amount Received', invoiceSendingPayload, null, 'sendInvoice');
};

const sendRemittance = (o) => {
  // console.log("sendRemittance:-", form);
  const remittanceSendingPayload = {
    form: o.form,
    sheetName: "Remittances Sent",
    id: o.id || null,
    action: 'sendRemittanceAdvice',
    selectedCoach: dd['Coaches'][o.form.coach]
  };
  chooseAndRunAction('Remittances Sent', remittanceSendingPayload, null, 'sendRemittanceAdvice');
};

const groupedByMonthAndGymAndCoach = tbl.reduce((acc, curr, i, arr) => {

  const month = curr.month;
  if (!acc[month]) {
    acc[month] = {};
  }
  if (!acc[month][curr.gym]) {
    acc[month][curr.gym] = {};
    const filtered = arr.filter(item => item.month === month && item.gym === curr.gym);
    const total = filtered.reduce((acc, curr) => {
      [30, 45, 60, 90, 120, "total"].forEach(d => {
        acc[d] = (acc[d] || 0) + curr[d];
      });
      return acc;
    }, {});



    [30, 45, 60, 90, 120].forEach(d => {
      const payRate = gymBoxRates[d] || 0;//gymBoxRates[curr.gym][d] for gymbased rates
      total[`gymBoxCost${d}`] = total[d] * payRate;
    });
    total['totalGymboxCost'] = [30, 45, 60, 90, 120].reduce((acc, curr) => {
      const payRate = gymBoxRates[curr] || 0;
      return acc + total[curr] * payRate;
    }, 0);
    const fines = fineTable.filter(item => item.month == month && item.gym == curr.gym);
    let tFine = 0;
    if (fines.length > 0) {
      tFine = fines.reduce((acc, curr) => {
        return (acc || 0) + curr.fine;
      }, 0);
    }
    total['fineAmount'] = tFine;
    total['totalCost'] = total['total'] - tFine;
    total['grossSales'] = total['totalGymboxCost'] - tFine;
    total['profit'] = total['grossSales'] - total['total'];
    total['VAT'] = total['grossSales'] * 0.20;
    total['sales'] = total['grossSales'] + total['VAT'];
    total['received'] = amountReceivedTable.find(item => item.month == month && item.gym == curr.gym)?.amount || 0;

    acc[month][curr.gym]['aggregates'] = total;

  }
  if (!acc[month][curr.gym][curr.coach]) {
    acc[month][curr.gym][curr.coach] = [];
  }
  acc[month][curr.gym][curr.coach].push(curr);
  return acc;
}, {});

const groupedByMonthAndCoachAndGym = tbl.reduce((acc, curr, i, arr) => {
  const month = curr.month;
  if (!acc[month]) {
    acc[month] = {};
  }
  if (!acc[month][curr.coach]) {
    acc[month][curr.coach] = {};
    const filtered = arr.filter(item => item.month === month && item.coach === curr.coach);
    const total = filtered.reduce((acc, curr) => {
      [30, 45, 60, 90, 120, "total"].forEach(d => {
        acc[d] = (acc[d] || 0) + curr[d];
      });
      return acc;
    }, {});
    const fines = fineTable.filter(item => item.month == month && item.coach == curr.coach);
    let tFine = 0;
    if (fines.length > 0) {
      tFine = fines.reduce((acc, curr) => {
        return (acc || 0) + curr.fine;
      }, 0);
    }
    total['fineAmount'] = tFine;
    total['totalCost'] = total['total'] - tFine;

    acc[month][curr.coach]['aggregates'] = total;

  }
  if (!acc[month][curr.coach][curr.gym]) {
    acc[month][curr.coach][curr.gym] = [];
  }
  acc[month][curr.coach][curr.gym].push(curr);
  return acc;
}, {});

// console.log("groupedByMonthAndCoachAndGym", groupedByMonthAndCoachAndGym);

const monthKeys = Object.keys(groupedByMonthAndGymAndCoach).map(month => ({ month }));
const monthKeysCoachWise = Object.keys(groupedByMonthAndCoachAndGym).map(month => ({ month }));
const gymKeys = computed(() => {
  const o = {};

  if (selectMonth.value) {
    const entries = groupedByMonthAndGymAndCoach[selectMonth.value.month];
    const arr = Object.keys(groupedByMonthAndGymAndCoach[selectMonth.value.month]).map(gym => ({ gym, entries: entries[gym], ...entries[gym]['aggregates'] }));
    console.log("arr", arr);
    const stats = ['totalCost', 'sales', 'received', 'profit'].reduce((acc, curr) => {
      acc[curr] = arr.reduce((sum, c) => {
        return sum + c[curr];
      }, 0);
      return acc;
    }, {});

    console.log("stats", stats);
    const statsCard = [
      { title: 'Gymbox Revenue', value: stats.sales },
      { title: 'Total Received Amount', value: stats.received },
      { title: 'Paid Out', value: stats.totalCost },
      { title: 'Profit', value: stats.sales - stats.totalCost }
    ];
    o.arr = arr;
    o.statsCard = statsCard;
    return o;
  }
  return null;
});




// console.log("gymKeys", gymKeys);

const coachKeys = computed(() => {
  if (selectedMonthCoachWise.value) {
    return Object.keys(groupedByMonthAndCoachAndGym[selectedMonthCoachWise.value.month]).map(coach => {
      const entries = groupedByMonthAndCoachAndGym[selectedMonthCoachWise.value.month][coach];
      return { coach, entries: entries, ...entries['aggregates'] };
    });
  }
  return null;
});

const gymFormatter = ({ gym }) => {
  return dd['Gyms'][gym].name;
};
const coachFormatter = ({ coach }) => {
  return dd['Coaches'][coach].name;
};
const monthFormatter = ({ month }) => {
  return new Date(month).toLocaleString('default', { month: 'short', year: 'numeric' });
};
const currencyFormatter = (value) => {
  return value.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' });
};

const processEntries = (entries, gym) => {
  const result = [];
  const coaches = Object.keys(entries);
  console.log("coaches", coaches);
  // const gym = entries[coaches[0]][coaches[0]].gym;
  const coachesInFineEntries = fineTable.filter(item => item.month == selectMonth.value.month && item.gym == gym).map(item => item.coach.toString());
  console.log("coachesInFineEntries", coachesInFineEntries);
  const remainingCoaches = coachesInFineEntries.filter(coach => !coaches.includes(coach));
  console.log("remainingCoaches", remainingCoaches);


  for (const coach in entries) {
    // const gym = entries[coach][0].gym;
    if (entries.hasOwnProperty(coach) && Array.isArray(entries[coach])) {
      let countOf30 = 0;
      let countOf45 = 0;
      let countOf60 = 0;
      let countOf90 = 0;
      let countOf120 = 0;
      // console.log("entries[coach][0]", entries[coach][0]);

      entries[coach].forEach(entry => {
        switch (entry.duration) {
          case 30:
            countOf30++;
            break;
          case 45:
            countOf45++;
            break;
          case 60:
            countOf60++;
            break;
          case 90:
            countOf90++;
            break;
          case 120:
            countOf120++;
            break;
        }
      });

      let total = 0;
      [30, 45, 60, 90, 120].forEach(duration => {
        const payRate = dd['Coaches'][coach][duration];
        switch (duration) {
          case 30:
            total += countOf30 * payRate;
            break;
          case 45:
            total += countOf45 * payRate;
            break;
          case 60:
            total += countOf60 * payRate;
            break;
          case 90:
            total += countOf90 * payRate;
            break;
          case 120:
            total += countOf120 * payRate;
            break;
        }
      });

      const fineEntries = fineTable.filter(item => {
        return (item.month == selectMonth.value.month && item.gym == gym && item.coach == coach);
      });

      let fineAmount = 0;
      // console.log("fineEntries", fineEntries);
      if (fineEntries.length > 0) {
        fineAmount = fineEntries.reduce((acc, curr) => {
          return (acc || 0) + curr.fine;
        }, 0);
      }

      result.push({
        coach: parseInt(coach),
        countOf30: countOf30,
        countOf45: countOf45,
        countOf60: countOf60,
        countOf90: countOf90,
        countOf120: countOf120,
        total: total,
        fineAmount: fineAmount,
        totalAfterFine: total - fineAmount
      });
    }
  }

  remainingCoaches.forEach(coach => {
    let fineAmount = 0;
    const fineEntries = fineTable.filter(item => {
      return (item.month == selectMonth.value.month && item.gym == gym && item.coach == coach);
    });
    if (fineEntries.length > 0) {
      fineAmount = fineEntries.reduce((acc, curr) => {
        return (acc || 0) + curr.fine;
      }, 0);
    }
    result.push({
      coach: parseInt(coach),
      countOf30: 0,
      countOf45: 0,
      countOf60: 0,
      countOf90: 0,
      countOf120: 0,
      total: 0,
      fineAmount: fineAmount,
      totalAfterFine: 0 - fineAmount
    });
  });
  selectInvoiceRow(selectMonth.value.month, gym);
  return result;
}

const processEntriesCoachWise = (entries, coach) => {
  const result = [];
  const gyms = Object.keys(entries);
  console.log("gyms", gyms);
  const gymInFineEntries = fineTable.filter(item => item.month == selectedMonthCoachWise.value.month && item.coach == coach).map(item => item.gym.toString());
  console.log("gymInFineEntries", gymInFineEntries);
  const remainingGyms = gymInFineEntries.filter(gym => !gyms.includes(gym));
  console.log("remainingGyms", remainingGyms);
  for (const gym in entries) {
    if (entries.hasOwnProperty(gym) && Array.isArray(entries[gym])) {
      let countOf30 = 0;
      let countOf45 = 0;
      let countOf60 = 0;
      let countOf90 = 0;
      let countOf120 = 0;
      // console.log("entries[coach][0]", entries[coach][0]);

      entries[gym].forEach(entry => {
        switch (entry.duration) {
          case 30:
            countOf30++;
            break;
          case 45:
            countOf45++;
            break;
          case 60:
            countOf60++;
            break;
          case 90:
            countOf90++;
            break;
          case 120:
            countOf120++;
            break;
        }
      });

      let total = 0;
      [30, 45, 60, 90, 120].forEach(duration => {
        const payRate = dd['Coaches'][coach][duration];
        switch (duration) {
          case 30:
            total += countOf30 * payRate;
            break;
          case 45:
            total += countOf45 * payRate;
            break;
          case 60:
            total += countOf60 * payRate;
            break;
          case 90:
            total += countOf90 * payRate;
            break;
          case 120:
            total += countOf120 * payRate;
            break;
        }
      });

      const fineEntries = fineTable.filter(item => {
        return (item.month == selectedMonthCoachWise.value.month && item.gym == gym && item.coach == coach);
      });

      let fineAmount = 0;
      // console.log("fineEntries", fineEntries);
      if (fineEntries.length > 0) {
        fineAmount = fineEntries.reduce((acc, curr) => {
          return (acc || 0) + curr.fine;
        }, 0);
      }

      result.push({
        gym: parseInt(gym),
        countOf30: countOf30,
        countOf45: countOf45,
        countOf60: countOf60,
        countOf90: countOf90,
        countOf120: countOf120,
        total: total,
        fineAmount: fineAmount,
        totalAfterFine:
          total - fineAmount,
      });
    }
  }

  remainingGyms.forEach(gym => {
    let fineAmount = 0;
    const fineEntries = fineTable.filter(item => {
      return (item.month == selectedMonthCoachWise.value.month && item.gym == gym && item.coach == coach);
    });
    if (fineEntries.length > 0) {
      fineAmount = fineEntries.reduce((acc, curr) => {
        return (acc || 0) + curr.fine;
      }, 0);
    }
    result.push({
      gym: parseInt(gym),
      countOf30: 0,
      countOf45: 0,
      countOf60: 0,
      countOf90: 0,
      countOf120: 0,
      total: 0,
      fineAmount: fineAmount,
      totalAfterFine: 0 - fineAmount
    });
  });
  selectRemittanceRow(selectedMonthCoachWise.value.month, coach);
  return result;
}

</script>

<style lang="scss" scoped>
.month {
  // background-color: #f8f8f8;
  align-content: start;
  padding: 10px;
  width: 100px;
  height: 1000px;
  overflow-y: auto;
}

.gym {
  // background-color: #f8f8f8;
  padding: 10px;
  justify-content: start;
  height: 1000px;
  overflow-y: auto;
}

.container {
  display: flex;
  flex-direction: row;
  background-color: #f8faff;
}

.stats-card {
  margin-top: 10px;
  padding: 10px;
  margin-bottom: 10px;
}

.amount-positive {
  color: green;
}
</style>
