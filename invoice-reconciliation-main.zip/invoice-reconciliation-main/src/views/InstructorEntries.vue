<script setup lang="jsx">
import SmartTable from '~/components/SmartTable.vue'
import { useAppStore } from "~/stores/appStore";

const appStore = useAppStore();
const { loggedUser } =
  appStore;
console.log('loggedUser in InstructorEntries.vue :-', loggedUser);

</script>
<template>
  <main>
    <div>
      <SmartTable :defaultFormValues="loggedUser?.id ? { coach: loggedUser?.id } : null" />
    </div>
  </main>
</template>
