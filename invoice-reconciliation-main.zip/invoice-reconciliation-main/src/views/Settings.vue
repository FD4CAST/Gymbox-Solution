<script setup>
import { allSheetNames } from '~/schema'
import { doHardReset, doSetup, saveInstructorsToScriptProperties } from '~/services'
import { useAppStore } from '~/stores/appStore'
import Vue3Html2pdf from 'vue3-html2pdf'

const appStore = useAppStore();
const html2Pdf = ref(null);
const { tables } =
  appStore;

const instructors = tables['Coaches'];
const invoice = {
  from: {
    name: "Sparring Partners Ltd",
    address: "Unit 7,38 New Kent Road,London,SE1 6TJ",
  },

  to: {
    name: "Sparring Partners Ltd",
    address: "Unit 7,38 New Kent Road,London,SE1 6TJ",
  },
  number: "123456",
  date: "2021-01-01",
  // Date, Class Taught, Instructor, Time,Duration, Rate, Total
  items: [
    {
      date: "2021-01-01",
      class: "Yoga",
      instructor: "John Doe",
      time: "10:00 AM",
      duration: "1 hour",
      rate: 10,
      total: 10
    },
    {
      date: "2021-01-02",
      class: "Pilates",
      instructor: "Jane Doe",
      time: "11:00 AM",
      duration: "1 hour",
      rate: 10,
      total: 10
    },
    {
      date: "2021-01-03",
      class: "Zumba",
      instructor: "John Doe",
      time: "12:00 PM",
      duration: "1 hour",
      rate: 10,
      total: 10
    },
    {
      date: "2021-01-04",
      class: "Kickboxing",
      instructor: "Jane Doe",
      time: "1:00 PM",
      duration: "1 hour",
      rate: 10,
      total: 10
    },
    {
      date: "",
      class: "",
      instructor: "",
      time: "",
      duration: "",
      rate: 'Fine',
      total: 2,
    },
    {
      date: "",
      class: "",
      instructor: "",
      time: "",
      duration: "",
      rate: 'Sub Total',
      total: 38,
      cls: 'sub-total'
    },
    {
      date: "",
      class: "",
      instructor: "",
      time: "",
      duration: "",
      rate: 'VAT',
      total: 2,
      cls: 'sub-total'
    },
    {
      date: "",
      class: "",
      instructor: "",
      time: "",
      duration: "",
      rate: 'Total',
      total: 42,
      cls: 'total'
    }
  ],
  invoiceFooter: {
    'Sub Total': 40,
    'VAT': 2,
    'Total': 42
  },

  invoiceParams: {
    "Name": "Elite Combat Agency",
    "Month Being Invoiced": "Apr",
    "Club being invoiced": "Old Street",
    "Bank Name": "Metro",
    "Account Number": "Elite Combat Agency  22042734",
    "Sort Code": "23 05 80",
    "Invoice Date": "30.04.2024",
    "Invoice Number": "751"
  },
  pageFooter: {
    line1: "Elite Combat Agency 68 Grosvenor Road Tunbridge Wells England TN1 2AS Registration Number: 10323962  VAT: 296 8016 66"
  }

};

const tableRowClassName = ({ row, rowIndex }) => {
  if (row.cls === 'sub-total') {
    return 'sub-total-row';
  } else if (row.cls === 'total') {
    return 'total-row';
  }
  return '';
};
const currencyFormatter = (row, column, cellValue) => {
  if (typeof cellValue === 'string') {
    return cellValue;
  }
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP'
  }).format(cellValue);
};


const createPdf = () => {
  const pdfOptions = {
    filename: "mypdf.pdf",
    image: { type: "jpeg", quality: 1 },
    margin: 1.5,
    html2canvas: {
      scale: 4,
      letterRendering: true,
      useCORS: true,
    },
    jsPDF: { orientation: "portrait", format: "a4", unit: "in" },
  };
  html2Pdf.value.generatePdf(pdfOptions);
};

const pdfCreated = (pdfBlob) => {
  console.log("pdfCreated", pdfBlob);

  // const fr = new FileReader();
  // fr.onload = (e) => {
  //   const data = e.target.result.split(",");
  //   const obj = {
  //     fileName: "mypdf.pdf",
  //     mimeType: data[0].match(/:(\w.+);/)[1],
  //     data: data[1],
  //   };

  //   google.script.run
  //     .withSuccessHandler((res) => {
  //       console.log("Uploaded File url", res);
  //       invoicePayload.invoice = res;
  //       if (tblName === "tbl_invoice") {
  //         configStore.updateItems(
  //           JSON.parse(invoicePayload.ts_ids),
  //           "tbl_timesheet",
  //           {
  //             invoiced: "Y",
  //           }
  //         );
  //       }
  //       configStore.updateOrAddItem(invoicePayload, tblName);
  //       this.$bvToast.toast(
  //         "Invoice saved successfully! Go to Invoice Records to send it to the client or take other actions.",
  //         {
  //           title: `Success`,
  //           variant: "success",
  //           solid: true,
  //         }
  //       );
  //       this.$router.push(goBackTo);
  //     })
  //     .saveInvoice(obj, tblName, invoicePayload);
  // };
  // fr.readAsDataURL(pdfBlob);
};


</script>

<template>
  <main>
    <h1>{{ `Settings` }}</h1>
    <el-button plain @click="doHardReset(allSheetNames)">
      Hard Reset
    </el-button>
    <el-button plain @click="doSetup(allSheetNames)">
      Setup
    </el-button>
    <el-button plain @click="saveInstructorsToScriptProperties(instructors)">
      Generate Instructors Links
    </el-button>
    <el-button plain @click="createPdf">
      Download Sample Invoice
    </el-button>


    <div>
      <vue3-html2pdf :show-layout="false" :float-layout="true" :enable-download="true" :preview-modal="false"
        :paginate-elements-by-height="1600" filename="Invoice" :pdf-quality="4" :manual-pagination="false"
        pdf-format="a4" pdf-orientation="portrait" pdf-content-width="800px" @hasDownloaded="pdfCreated($event)"
        ref="html2Pdf">
        <template v-slot:pdf-content>
          <el-container class="container">
            <el-header class="header">
              <div class="invoice-header">
                <div class="title">INVOICE</div>
                <div class="image"><img src="https://i.ibb.co/thTrDY1/Whats-App-Image-2024-05-24-at-5-48-54-PM.jpg"
                    alt="Whats-App-Image-2024-05-24-at-5-48-54-PM" border="0"></div>
              </div>

            </el-header>
            <hr>

            <el-main class="main">
              <el-descriptions title="" border :column="2" size="small" direction="vertical">
                <el-descriptions-item label="Invoice To">
                  <div>{{ invoice.from.name }}</div>
                  <div class="address-line" v-for="line in invoice.from.address.split(',')">{{ line }}</div>
                </el-descriptions-item>
                <el-descriptions-item label="Invoice From">
                  <div>{{ invoice.to.name }}</div>
                  <div class="address-line" v-for="line in invoice.from.address.split(',')">{{ line }}</div>
                </el-descriptions-item>
              </el-descriptions>
              <br>
              <el-descriptions class="" title="" :column="2" size="small" border>
                <!-- <template #extra>
                        <el-button type="primary">Operation</el-button>
                    </template> -->
                <el-descriptions-item v-for="[k, v] of Object.entries(invoice.invoiceParams)" :label="k"
                  class-name="description-item" label-class-name="description-label">
                  {{ v }}
                </el-descriptions-item>
              </el-descriptions>
              <br>
              <!-- Add Invoice Table -->
              <el-table :data="invoice.items" :row-class-name="tableRowClassName" border size="small">
                <el-table-column prop="date" label="Date" width="90"></el-table-column>
                <el-table-column prop="class" label="Class" width="130"></el-table-column>
                <el-table-column prop="instructor" label="Instructor"></el-table-column>
                <el-table-column prop="time" label="Time" width="70"></el-table-column>
                <el-table-column prop="duration" label="Duration" width="70"></el-table-column>
                <el-table-column prop="rate" label="Rate" :formatter="currencyFormatter" width="70"></el-table-column>
                <el-table-column prop="total" label="Total" :formatter="currencyFormatter" width="60"></el-table-column>

              </el-table>
              <br>



            </el-main>
            <el-footer class="footer">
              <div>{{ invoice.pageFooter.line1 }}</div>
            </el-footer>
          </el-container>
        </template>
      </vue3-html2pdf>
    </div>
  </main>
</template>
<style scoped>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;

}

.container {
  height: 102vh;
  display: flex;
  flex-direction: column;
}

.header {
  background-color: #ffffff;
  color: rgb(93, 93, 93);
  text-align: center;
  height: 100px;
  /* Add bottom border */
  border-bottom: 2px solid #858585;
}

.invoice-header {
  display: flex;
  direction: row;
  justify-content: space-between;
  padding-top: 20px;
}

.invoice-header .title {
  font-size: 32px;
  font-weight: bold;
}

.main {
  /* background-color: #67C23A; */
  color: white;
  text-align: center;
}

.footer {
  background-color: #ffffff;
  padding-top: 10px;
  height: 40px;
  color: rgb(84, 80, 80);
  text-align: center;
  font-size: 10px;
  /* add top border */
  border-top: 2px solid #858585;
}

.el-table .sub-total-row {
  background-color: #efefef;
}

.el-table .total-row {
  background-color: #efefef;
  font-weight: bold;
}

/* dark table header */
.el-table tr {
  font-size: 9px;
}

.el-table th {
  background-color: #efefef !important;
  color: #221717;
}

.image img {
  width: 300px;

}

.description-item {
  font-size: 9px !important;
  line-height: 10px !important;
  padding: 2px;
}

.description-label {
  font-size: 9px !important;
  line-height: 10px !important;
  padding: 2px;
}

.address-line {

  line-height: 1.2;
  padding: 0;
  font-size: 10px;
}

#app {
  padding: 10px;
}
</style>