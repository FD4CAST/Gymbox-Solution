// { action, sheetName, id = null, form = null } <- paremeter
export const executeAction = async (payload) => {
  return new Promise((resolve, reject) => {
    google.script.run
      .withSuccessHandler((res) => {
        console.log("success", res);
        resolve(res); // Resolve the promise with the response from the server
      })
      .withFailureHandler((error) => {
        console.log("failure", error);
        reject(error); // Reject the promise with the error from the server
      })
      .executeAction(payload);
  });
};

export const doHardReset = async (sheetNames) => {
  return new Promise((resolve, reject) => {
    google.script.run
      .withSuccessHandler((res) => {
        console.log("success", res);
        resolve(res); // Resolve the promise with the response from the server
      })
      .withFailureHandler((error) => {
        console.log("failure", error);
        reject(error); // Reject the promise with the error from the server
      })
      .DoHardReset(sheetNames);
  });
};

export const doSetup = async (sheetNames) => {
  return new Promise((resolve, reject) => {
    google.script.run
      .withSuccessHandler((res) => {
        console.log("success", res);
        resolve(res); // Resolve the promise with the response from the server
      })
      .withFailureHandler((error) => {
        console.log("failure", error);
        reject(error); // Reject the promise with the error from the server
      })
      .DoSetup(sheetNames);
  });
};

export const saveInstructorsToScriptProperties = async (instructors) => {
  return new Promise((resolve, reject) => {
    google.script.run
      .withSuccessHandler((res) => {
        console.log("success", res);
        resolve(res); // Resolve the promise with the response from the server
      })
      .withFailureHandler((error) => {
        console.log("failure", error);
        reject(error); // Reject the promise with the error from the server
      })
      .saveInstructorsToScriptProperties(instructors);
  });
};

export const uploadFile = async (file) => {
  return new Promise((resolve, reject) => {
    google.script.run
      .withSuccessHandler((res) => {
        console.log("File Upload success", res);
        resolve(res); // Resolve the promise with the response from the server
      })
      .withFailureHandler((error) => {
        console.log("failure", error);
        reject(error); // Reject the promise with the error from the server
      })
      .uploadFile(file);
  });
};
