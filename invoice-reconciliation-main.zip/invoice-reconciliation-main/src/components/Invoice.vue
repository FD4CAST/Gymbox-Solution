<script setup>
import { useAppStore } from '~/stores/appStore';
import { companyInfo, gymBoxRates } from '~/helpers';

const props = defineProps({
    data: {
        type: Object,
        required: false,
    },
    invoiceForm: {
        type: Object,
        required: false,
    },
});
const appStore = useAppStore();

const { indexedTables } =
    appStore;
const dd = indexedTables;
const gym = props.data.selectedGym;
const classTaught = dd['Classes Taught'];
console.log('Month beig invoiced:', props.data.selectedMonth);
const month = new Date(props.data.selectedMonth).toLocaleString('default', { month: 'short', year: 'numeric' });
// format date like 
// console.log('gym', gym);
// console.log('props.data', props.data);
let entries = props.data.entries;
const fines = props.data.fineEntries;
const fineAmount = fines.reduce((acc, row) => acc + row.fine, 0);
entries = entries.map((entry) => {
    const { duration } = entry;
    const rate = gymBoxRates[duration];
    const total = entry[duration] * rate;
    return { ...entry, rate, total };
});
entries.push({
    date: '',
    clTaught: '',
    coach: '',
    duration: 'Fines',
    rate: fines.length.toString(),
    total: -fineAmount,
});
const st = entries.reduce((acc, row) => acc + row.total, 0);
const o = {
    'Sub Total': st,
    'VAT': st * 0.2,
    'Total': st + st * 0.2
}
Object.entries(o).forEach(([k, v]) => {
    entries.push({
        date: '',
        clTaught: '',
        coach: '',
        duration: '',
        rate: k,
        total: v,
        cls: k === 'Total' ? 'total' : 'sub-total'
    });
});
console.log('entries', entries);
const invoice = reactive({
    from: {
        name: companyInfo.name,
        address: companyInfo.address,
    },
    to: {
        name: gym.name,
        address: gym.address,
    },
    number: companyInfo.registrationNumber,
    date: new Date().toLocaleDateString('en-GB'),
    pageFooter: {
        line1: "Elite Combat Agency 68 Grosvenor Road Tunbridge Wells England TN1 2AS Registration Number: 10323962  VAT: 296 8016 66"
    }

});
const tableRowClassName = ({ row, rowIndex }) => {
    if (row.cls === 'sub-total') {
        return 'sub-total-row';
    } else if (row.cls === 'total') {
        return 'total-row';
    }
    return '';
};

const currencyFormatter = (row, column, cellValue) => {
    if (typeof cellValue === 'string') {
        return cellValue;
    }
    return new Intl.NumberFormat('en-GB', {
        style: 'currency',
        currency: 'GBP'
    }).format(cellValue);
};

const classFormatter = (row, column, cellValue) => {
    if (!cellValue) {
        return '';
    }
    return dd['Classes Taught'][cellValue]?.name;
};
const instructorFormatter = (row, column, cellValue) => {
    if (!cellValue) {
        return '';
    }
    return dd['Coaches'][cellValue]?.name;
};
const dateFormatter = (row, column, cellValue) => {
    return new Intl.DateTimeFormat('en-GB').format(new Date(cellValue));
};

const dateAndTimeFormatter = (row, column, cellValue) => {
    if (!cellValue) {
        return '';
    }
    const options = {
        year: 'numeric', month: 'numeric', day: 'numeric',
        hour: 'numeric', minute: 'numeric', second: 'numeric',
        hour12: false,
    };
    return new Intl.DateTimeFormat('en-GB', options).format(new Date(cellValue));
}

</script>

<template>
    <el-container class="container">
        <el-header class="header">
            <div class="invoice-header">
                <div class="title">INVOICE</div>
                <div class="image"><img src="https://i.ibb.co/thTrDY1/Whats-App-Image-2024-05-24-at-5-48-54-PM.jpg"
                        alt="Whats-App-Image-2024-05-24-at-5-48-54-PM" border="0"></div>
            </div>
        </el-header>
        <hr>

        <el-main class="main">
            <el-descriptions title="" border :column="2" size="small" direction="vertical">
                <el-descriptions-item label="Invoice To">
                    <div>{{ invoice.to.name }}</div>
                    <div class="address-line" v-for="line in invoice.to.address.split(',')">{{ line }}
                    </div>
                </el-descriptions-item>
                <el-descriptions-item label="Invoice From">
                    <div>{{ invoice.from.name }}</div>
                    <div class="address-line" v-for="line in invoice.from.address.split(',')">{{ line }}
                    </div>
                </el-descriptions-item>
            </el-descriptions>
            <br>
            <el-descriptions class="" title="" :column="2" size="small" border>
                <el-descriptions-item label="Name">{{ companyInfo.name }}</el-descriptions-item>
                <el-descriptions-item label="Month Being Invoiced">{{ month }}</el-descriptions-item>
                <el-descriptions-item label="Club being invoiced">{{ gym.name }}</el-descriptions-item>
                <el-descriptions-item label="Bank Name">{{ companyInfo.bankName }}</el-descriptions-item>
                <el-descriptions-item label="Account Number">{{ companyInfo.bankAcc }}</el-descriptions-item>
                <el-descriptions-item label="Sort Code">{{ companyInfo.sortCode }}</el-descriptions-item>
                <el-descriptions-item label="Invoice Date">{{ new
                Date(invoiceForm.invoiceDate).toLocaleDateString('en-GB') }}</el-descriptions-item>
                <el-descriptions-item label="Invoice Number">{{ `${companyInfo.invoicePrefix}
                    ${invoiceForm.invoiceNumber.toString().padStart(3, "0")}` }}</el-descriptions-item>

            </el-descriptions>
            <br>
            <!-- Add Invoice Table -->
            <el-table :data="entries" :row-class-name="tableRowClassName" border size="small">
                <el-table-column prop="date" label="Date" :formatter="dateAndTimeFormatter"></el-table-column>
                <el-table-column prop="clTaught" label="Class" width="160"
                    :formatter="classFormatter"></el-table-column>
                <el-table-column prop="coach" label="Instructor" :formatter="instructorFormatter"
                    width="160"></el-table-column>
                <!-- <el-table-column prop="time" label="Time" width="70"></el-table-column> -->
                <el-table-column prop="duration" label="Duration" width="70"></el-table-column>
                <el-table-column prop="rate" label="Rate" :formatter="currencyFormatter" width="90"></el-table-column>
                <el-table-column prop="total" label="Total" :formatter="currencyFormatter" width="90"></el-table-column>
            </el-table>
            <br>

        </el-main>
        <el-footer class="footer">
            <div>{{ invoice.pageFooter.line1 }}</div>
        </el-footer>
    </el-container>

</template>
<style scoped>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;

}

.container {
    height: 1060px;
    display: flex;
    flex-direction: column;
}

.header {
    background-color: #ffffff;
    color: rgb(93, 93, 93);
    text-align: center;
    height: 100px;
    /* Add bottom border */
    border-bottom: 2px solid #858585;
}

.invoice-header {
    display: flex;
    direction: row;
    justify-content: space-between;
    padding-top: 20px;
}

.invoice-header .title {
    font-size: 32px;
    font-weight: bold;
}

.main {
    /* background-color: #67C23A; */
    color: white;
    text-align: center;
}

.footer {
    background-color: #ffffff;
    padding-top: 10px;
    height: 40px;
    color: rgb(84, 80, 80);
    text-align: center;
    font-size: 10px;
    /* add top border */
    border-top: 2px solid #858585;
}

.el-table .sub-total-row {
    background-color: #efefef;
}

.el-table .total-row {
    background-color: #efefef;
    font-weight: bold;
}

/* dark table header */
.el-table tr {
    font-size: 9px;
}

.el-table th {
    background-color: #efefef !important;
    color: #221717;
}

.image img {
    width: 300px;

}

.description-item {
    font-size: 9px !important;
    line-height: 10px !important;
    padding: 2px;
}

.description-label {
    font-size: 9px !important;
    line-height: 10px !important;
    padding: 2px;
}

.address-line {

    line-height: 1.2;
    padding: 0;
    font-size: 10px;
}

#app {
    padding: 10px;
}
</style>