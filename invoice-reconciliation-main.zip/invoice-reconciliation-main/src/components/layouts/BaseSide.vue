<template>
    <el-menu class="el-menu-demo" mode="horizontal" :ellipsis="false" @select="handleSelect"
        :default-active="activeIndex">
        <el-menu-item index="-1">
            <div class="image"><img src="https://i.ibb.co/thTrDY1/Whats-App-Image-2024-05-24-at-5-48-54-PM.jpg"
                    alt="Whats-App-Image-2024-05-24-at-5-48-54-PM" border="0" style="width:294px;"></div>
        </el-menu-item>
        <div class="flex-grow" />
        <div v-for="(menu, i) in menus" :key="i">
            <el-sub-menu v-if="menu.menus" :index="i.toString()">
                <template #title>{{ menu.title }}</template>
                <el-menu-item v-for="(submenu, j) in menu.menus" :index="`${i}-${j}`" :key="`${i}-${j}`">
                    <RouterLink :to="submenu.path">{{ submenu.title }}</RouterLink>
                </el-menu-item>
            </el-sub-menu>
            <el-menu-item v-else :index="i.toString()">
                <RouterLink :to="menu.path">{{ menu.title }}</RouterLink>
            </el-menu-item>
        </div>
    </el-menu>
</template>
<script setup>
import { ref } from 'vue'
import { RouterLink } from 'vue-router'
import { ElMenu, ElSubMenu, ElMenuItem } from 'element-plus'
import { menuSchema } from '~/schema'


const loggedUserData = JSON.parse(
    document.getElementById("loggedUser").innerHTML
);
const isAdmin = loggedUserData?.isAdmin;
let filteredMenus = null;
if (isAdmin) {
    filteredMenus = menuSchema;
} else {
    // Filter out the menus and submenus who has got hidden property set to true
    filteredMenus = menuSchema.filter(menu => {
        if (menu.menus) {
            menu.menus = menu.menus.filter(submenu => !submenu.hidden)
            return menu.menus.length > 0
        }
        return !menu.hidden
    });

}
const menus = ref(filteredMenus)
const activeIndex = ref('1')

const handleSelect = (key, keyPath) => {
    activeIndex.value = key
}
</script>

<style scoped>
/* Style for the menu */
.el-menu-demo {
    background-color: rgb(255, 255, 255);
    border-bottom: 2px solid rgb(31, 128, 255);
}

/* Style for Router Link */
a {
    color: var(--ep-text-color-primary);
    text-decoration: none;
}

/* Style active Router Link */
a.router-link-active {
    color: var(--ep-text-color-active);
    font-weight: bold;
}

/* Custom styles for active menu item */
.el-menu-demo .el-menu-item.is-active {
    background-color: var(--ep-active-color);
    color: var(--ep-text-color-active);
}

.el-menu-demo .el-sub-menu__title.is-active {
    background-color: var(--ep-active-color);
    color: var(--ep-text-color-active);
}

.image {
    padding-bottom: 8px;
}
</style>