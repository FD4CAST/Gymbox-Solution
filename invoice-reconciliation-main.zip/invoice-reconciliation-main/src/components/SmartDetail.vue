<script setup lang="jsx">
import { taskSchema, getModel } from "~/schema";
import { uploadFile } from "~/services";

const props = defineProps({
  form: {
    type: Object,
    required: false,
  },
  schema: {
    type: Object,
    required: true,
  },
  dd: {
    type: Object,
    required: false,
  },
});



const getFormattedValue = (fld, value) => {
  if (fld.cellRenderer) {
    switch (fld.type) {
      case "date":
        return new Date(value).toLocaleDateString();
      case "datetime":
        return new Date(value).toLocaleString();
      case "select":
        return value;
      default:
        return value;
    }
  }
  if (fld.optionConfig) {
    return props.dd[fld.optionConfig.source][value][fld.optionConfig.label];
  } else {
    return value;
  }
};
</script>

<template>
  <!-- <div v-for="(fld, i) in schema.fields" :key="i">
    <div v-if="fld.fields">
      <el-table :data="form[fld.key]">
        <el-table-column v-for="(subFld, j) in fld.fields" :key="j" :label="subFld.label" :prop="subFld.key" :formatter="(row, column, value) => {
    if (subFld.optionConfig) {
      return dd[subFld.optionConfig.source][value][
        subFld.optionConfig.label
      ];
    } else {
      return value;
    }
  }
    "></el-table-column>
      </el-table>
    </div>
    <div v-else>

      <el-row>
        <el-col :span="6" class="flex align-left">
          {{ fld.label }}
        </el-col>
        <el-col :span="18">
          <strong> {{ form[fld.key] }}</strong>
        </el-col>
      </el-row>
    </div>
  </div> -->


  <el-descriptions title="Detail View" :column="1" border>
    <div v-for="(fld, i) in schema.fields" :key="i">
      <div v-if="fld.fields">
        <el-descriptions-item #default :span="24" :label="fld.label"><el-table :data="form[fld.key]">
            <el-table-column v-for="(subFld, j) in fld.fields" :key="j" :label="subFld.label" :prop="subFld.key"
              :formatter="(row, column, value) => {
    if (subFld.cellRenderer) {
      return subFld.cellRenderer({ cellData: value });
    }
    if (subFld.optionConfig) {
      return dd[subFld.optionConfig.source][value][
        subFld.optionConfig.label
      ];
    } else {
      return value;
    }
  }
    "></el-table-column>
          </el-table></el-descriptions-item>
      </div>
      <div v-else>

        <el-descriptions-item :label="fld.label">{{ getFormattedValue(fld, form[fld.key])
          }}</el-descriptions-item>
      </div>
    </div>




  </el-descriptions>

</template>

<style scoped></style>
