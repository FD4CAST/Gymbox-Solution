<script setup>
import { useAppStore } from '~/stores/appStore'
import { companyInfo, maskString, getREFNo } from '~/helpers'

const props = defineProps({
    data: {
        type: Object,
        required: false,
    },
    remittanceForm: {
        type: Object,
        required: false,
    },
});
const appStore = useAppStore();

const { indexedTables } =
    appStore;

const coach = props.data.selectedCoach;
const month = props.data.selectedMonth;
console.log('Remittance Month:', month);
const gymDD = indexedTables['Gyms'];
console.log("Remittance Form in Remittance PDF:-", props.remittanceForm);

const remittanceTbl = [];
[30, 45, 60, 90, 120].forEach((d) => {
    props.data.entries.forEach((o) => {
        if (o[`countOf${d}`] > 0) {
            remittanceTbl.push({
                gym: o.gym,
                count: o[`countOf${d}`],
                duration: d,
                rate: coach[d],
                total: o[`countOf${d}`] * coach[d]
            })
        }
    });
}
)
props.data.entries.forEach((o) => {
    if (o['fineAmount'] > 0) {
        remittanceTbl.push({
            gym: o.gym,
            count: "",
            duration: '',
            rate: "Fines",
            total: -o['fineAmount']
        })
    }
});

const total = remittanceTbl.reduce((acc, row) => acc + row.total, 0);
remittanceTbl.push({
    cls: 'total',
    gym: '',
    count: '',
    duration: '',
    rate: 'Total',
    total: total
});

console.log("Remittance Table in Remittance PDF:-", remittanceTbl);


const invoice = ref({
    from: {
        name: companyInfo.name,

    },

    to: {
        name: coach.name,

    },
    number: "123456",
    date: "2021-01-01",
    invoiceFooter: {
        'Sub Total': 40,
        'VAT': 2,
        'Total': 42
    },

    invoiceParams: {
        "ourRef": "XXX",
        "Remittance Data": new Date().toLocaleDateString('en-GB'),
        "Bank Account": "123456",
        "Sort Code": "22-22-22",
    },
    pageFooter: {
        line1: "Elite Combat Agency 68 Grosvenor Road Tunbridge Wells England TN1 2AS Registration Number: 10323962  VAT: 296 8016 66"
    }

});

const tableRowClassName = ({ row, rowIndex }) => {
    if (row.cls === 'sub-total') {
        return 'sub-total-row';
    } else if (row.cls === 'total') {
        return 'total-row';
    }
    return '';
};
const currencyFormatter = (row, column, cellValue) => {
    if (typeof cellValue === 'string') {
        return cellValue;
    }
    return new Intl.NumberFormat('en-GB', {
        style: 'currency',
        currency: 'GBP'
    }).format(cellValue);
};

const gymFormatter = (row, column, cellValue) => {
    if (!cellValue) {
        return '';
    }
    return gymDD[cellValue]?.name;
};
const dateFormatter = (row, column, cellValue) => {
    return new Intl.DateTimeFormat('en-GB').format(new Date(cellValue));
};


</script>

<template>
    <el-container class="container">
        <el-header class="header">
            <div class="invoice-header">
                <div class="title">Remittance Advice</div>
                <div class="image"><img :src="companyInfo.logo" alt="Company Logo" border="0"></div>
            </div>

        </el-header>
        <hr>

        <el-main class="main">
            <el-descriptions class="" title="" :column="2" size="small" border>

                <el-descriptions-item label="Our Ref" class-name="description-item"
                    label-class-name="description-label">
                    {{ remittanceForm.ourRef }}
                </el-descriptions-item>
                <el-descriptions-item label="Remittance Date" class-name="description-item"
                    label-class-name="description-label">
                    {{ dateFormatter(null, null, remittanceForm.date) }}
                </el-descriptions-item>
                <el-descriptions-item label="Bank Account" class-name="description-item"
                    label-class-name="description-label">
                    {{ maskString(remittanceForm.bankAccount) }}
                </el-descriptions-item>
                <el-descriptions-item label="Sort Code" class-name="description-item"
                    label-class-name="description-label">
                    {{ maskString(remittanceForm.sortCode, 2) }}
                </el-descriptions-item>
            </el-descriptions>
            <br>
            <el-descriptions title="" border :column="2" size="small" direction="vertical">
                <el-descriptions-item label="Remit To">
                    <div>{{ invoice.to.name }}</div>
                    <!-- <div class="address-line" v-for="line in invoice.from.address.split(',')">{{ line }}
                    </div> -->
                </el-descriptions-item>
                <el-descriptions-item label="Remit From">
                    <div>{{ invoice.from.name }}</div>
                    <!-- <div class="address-line" v-for="line in invoice.from.address.split(',')">{{ line }}
                    </div> -->
                </el-descriptions-item>
            </el-descriptions>
            <br>

            <!-- Add Invoice Table -->
            <el-table :data="remittanceTbl" :row-class-name="tableRowClassName" border size="small">
                <el-table-column prop="gym" label="Gym" :formatter="gymFormatter"></el-table-column>
                <el-table-column prop="count" label="Classes" width="90"></el-table-column>
                <el-table-column prop="duration" label="Duration" width="90"></el-table-column>
                <el-table-column prop="rate" label="Per Class" :formatter="currencyFormatter"
                    width="110"></el-table-column>
                <el-table-column prop="total" label="Amount Paid" :formatter="currencyFormatter"
                    width="130"></el-table-column>
            </el-table>
            <br>
            <div style="align-content: start;color:black;font-size: 9px;">
                <p>
                    BACS Payment
                </p>
                <p>
                    Payment should credit the account by the 15th of the month.Please note that all allocations should
                    be
                    done strictly in accordance with invoices/amounts
                    shown above.
                </p>
                <p>
                    All queries should be directed to finance.elitecombatagency@gmail.com
                    Elite Combat Agency Ltd Registered in United Kingdom No: 10323962
                    Registered address: 68 Grosvenor Road, Tunbridge Wells, England, TN1 2AS
                </p>
            </div>


        </el-main>
        <el-footer class="footer">
            <div>{{ invoice.pageFooter.line1 }}</div>
        </el-footer>
    </el-container>

</template>
<style scoped>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;

}

.container {
    /* height in pixel for a4 pdf generation */
    height: 1060px;
    display: flex;
    flex-direction: column;
}


.header {
    background-color: #ffffff;
    color: rgb(93, 93, 93);
    text-align: center;
    height: 90px;
    /* Add bottom border */
    border-bottom: 2px solid #858585;
}

.invoice-header {
    display: flex;
    direction: row;
    justify-content: space-between;
    padding-top: 20px;
}

.invoice-header .title {
    font-size: 32px;
    font-weight: bold;
}

.main {
    /* background-color: #67C23A; */
    color: white;
    text-align: center;
}

.footer {
    background-color: #ffffff;
    padding-top: 10px;
    height: 40px;
    color: rgb(84, 80, 80);
    text-align: center;
    font-size: 8px;
    height: 60px;
    border-top: 2px solid #858585;
}

.el-table .sub-total-row {
    background-color: #efefef;
}

.el-table .total-row {
    /* background-color: #efefef; */
    font-weight: bold;
}

/* dark table header */
.el-table tr {
    font-size: 9px;
}

.el-table th {
    background-color: #efefef !important;
    color: #221717;
}

.image img {
    width: 300px;

}

.description-item {
    font-size: 9px !important;
    line-height: 10px !important;
    padding: 2px;
}

.description-label {
    font-size: 9px !important;
    line-height: 10px !important;
    padding: 2px;
}

.address-line {

    line-height: 1.2;
    padding: 0;
    font-size: 10px;
}

#app {
    padding: 10px;
}
</style>