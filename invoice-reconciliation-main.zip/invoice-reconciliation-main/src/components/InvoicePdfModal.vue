<script setup>
import { useAppStore } from '~/stores/appStore'
import { companyInfo } from '~/helpers'
import Vue3Html2pdf from 'vue3-html2pdf'
import Invoice from './Invoice.vue'

const props = defineProps({
    data: {
        type: Object,
        required: false,
    },
});

const appStore = useAppStore();
const invNumber = appStore.nextInvoiceNumber;
console.log('invNumber in InvoicePdfModal:-', invNumber);
const loading = ref(false);
const html2Pdf = ref(null);
const { savePDF } =
    appStore;
const month = props.data.selectedMonth;
const gym = props.data.selectedGym;
console.log('gym in Invice PDF moal:-', gym);
const monthString = new Date(month).toLocaleString('default', { month: 'short', year: 'numeric' });
const emit = defineEmits(["generated", "saved"]);
const fileName = `${monthString}-${gym.name}-invoice.pdf`;

const invoiceForm = ref({
    invoiceNumber: invNumber,
    invoiceDate: new Date(),
});
const createPdf = () => {
    loading.value = true;
    html2Pdf.value.generatePdf();
    emit("generated");
};
const pdfCreated = (pdfBlob) => {
    console.log("pdfCreated", pdfBlob);
    const form = {
        month: month,
        gym: parseInt(gym.id),
        status: "Invoiced",
        invoiceNumber: invoiceForm.invoiceNumber,
    }
    const payload = {
        form: form,
        sheetName: "Amount Received",
        id: null,
        action: 'add',
        selectedGym: gym
    }
    const fr = new FileReader();
    fr.onload = async (e) => {
        const data = e.target.result.split(",");
        const obj = {
            fileName: fileName,
            mimeType: data[0].match(/:(\w.+);/)[1],
            data: data[1],
        };
        await savePDF(obj, payload, "Invoices");
        emit("saved");
        loading.value = false;
    };
    fr.readAsDataURL(pdfBlob);
};

</script>

<template>
    <main>
        <el-button plain @click="createPdf">
            Save PDF
        </el-button>
        <el-card style="margin-top: 10px;margin-bottom: 10px;">
            <el-form :model="invoiceForm" size="small" label-width="auto">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="Invoice Number" size="small">
                            <el-input v-model="invoiceForm.invoiceNumber" placeholder="" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="Invoice Date" size="small">
                            <el-date-picker v-model="invoiceForm.invoiceDate" type="date" />
                        </el-form-item>
                    </el-col>
                </el-row>


            </el-form>
        </el-card>
        <div>
            <vue3-html2pdf :show-layout="false" :float-layout="true" :enable-download="true" :preview-modal="false"
                :paginate-elements-by-height="1600" :filename="fileName" :pdf-quality="4" :manual-pagination="false"
                pdf-format="a4" pdf-orientation="portrait" pdf-content-width="800px" @hasDownloaded="pdfCreated($event)"
                ref="html2Pdf">
                <template v-slot:pdf-content>
                    <Invoice :data="data" :invoiceForm="invoiceForm" />
                </template>
            </vue3-html2pdf>
        </div>
        <Invoice :data="data" :invoiceForm="invoiceForm" />
    </main>
</template>
