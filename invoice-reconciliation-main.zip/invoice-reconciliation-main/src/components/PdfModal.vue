<script setup>
import { useAppStore } from '~/stores/appStore'
import Vue3Html2pdf from 'vue3-html2pdf'
import Remittance from './Remittance.vue'
import { getREFNo } from '~/helpers'

const props = defineProps({
    data: {
        type: Object,
        required: false,
    },
});

console.log('props.data in PDF Modal :-', props.data);
const month = props.data.selectedMonth;
const coach = props.data.selectedCoach;

const monthString = new Date(month).toLocaleString('default', { month: 'short', year: 'numeric' });

const fileName = `${monthString}-${coach.name}-remittance.pdf`;

const appStore = useAppStore();
const html2Pdf = ref(null);
const { savePDF } =
    appStore;
const dt = new Date();
const fifteenthDate = dt.setDate(15);
const remittanceForm = ref({
    ourRef: getREFNo(coach.name, month),
    date: fifteenthDate,
    bankAccount: coach.account,
    sortCode: coach.sortCode,
});
const emit = defineEmits(["generated"]);

const createPdf = () => {
    html2Pdf.value.generatePdf();
    emit("generated");
};

const pdfCreated = (pdfBlob) => {
    console.log("pdfCreated", pdfBlob);
    const form = {
        month: month,
        coach: parseInt(coach.id),
        status: "Generated"
    }
    const payload = {
        form: form,
        sheetName: "Remittances Sent",
        id: null,
        action: 'add'
    }
    const fr = new FileReader();
    fr.onload = (e) => {
        const data = e.target.result.split(",");
        const obj = {
            fileName: fileName,
            mimeType: data[0].match(/:(\w.+);/)[1],
            data: data[1],
        };
        savePDF(obj, payload, "Remittance Advices");
    };
    fr.readAsDataURL(pdfBlob);
};


</script>

<template>
    <main>
        <el-button plain @click="createPdf" size="small" type="primary">
            Save PDF
        </el-button>

        <el-card style="margin-top: 10px;margin-bottom: 10px;">
            <el-form :model="remittanceForm" size="small" label-width="auto">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="Remittance Advice" size="small">
                            <el-input v-model="remittanceForm.ourRef" placeholder="" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="Date" size="small">
                            <el-date-picker v-model="remittanceForm.date" type="date" />
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="Bank Account" size="small">
                            <el-input v-model="remittanceForm.bankAccount" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="Sort Code" size="small">
                            <el-input v-model="remittanceForm.sortCode" />
                        </el-form-item>
                    </el-col>
                </el-row>
                <!-- <el-form-item label="Our Ref" size="small">
                    <el-input v-model="remittanceForm.ourRef" placeholder="" />
                </el-form-item>
                <el-form-item label="Date" size="small">
                    <el-date-picker v-model="remittanceForm.date" type="date" />
                </el-form-item>
                <el-form-item label="Bank Account" size="small">
                    <el-input v-model="remittanceForm.bankAccount" />
                </el-form-item>
                <el-form-item label="Sort Code" size="small">
                    <el-input v-model="remittanceForm.sortCode" />
                </el-form-item> -->
            </el-form>
        </el-card>
        <el-tag type="primary">Preview</el-tag>
        <hr>
        <div>
            <vue3-html2pdf :show-layout="false" :float-layout="true" :enable-download="true" :preview-modal="false"
                :paginate-elements-by-height="1600" :filename="fileName" :pdf-quality="4" :manual-pagination="false"
                pdf-format="a4" pdf-orientation="portrait" pdf-content-width="800px" @hasDownloaded="pdfCreated($event)"
                ref="html2Pdf">
                <template v-slot:pdf-content>
                    <Remittance :data="data" :remittanceForm="remittanceForm" />
                </template>
            </vue3-html2pdf>
        </div>
        <Remittance :data="data" :remittanceForm="remittanceForm" />
    </main>
</template>
