<script setup lang="jsx">
import { taskSchema, getModel } from "~/schema";
import { uploadFile } from "~/services";

const props = defineProps({
  form: {
    type: Object,
    required: false,
  },
  schema: {
    type: Object,
    required: true,
  },
  dd: {
    type: Object,
    required: false,
  },
  id: {
    type: Number,
    required: false,
  },
  initialValues: {
    type: Object,
    required: false,
  },
});



let emptyForm = getModel(props.schema.fields);
let receivedForm = getModel(props.schema.fields);
if (props.form) {
  receivedForm = props.form;
}
if (props.initialValues) {
  receivedForm = { ...receivedForm, ...props.initialValues };
  emptyForm = { ...emptyForm, ...props.initialValues };
}
const form = reactive(receivedForm);

const uploading = ref(false);
const submitting = ref(false);
const tempFileList = reactive([]);
const emit = defineEmits(["formSubmitted", "formCancelled"]);

const onSubmit = () => {
  console.log("submitted form", form);
  const requiredFlds = props.schema.fields.filter((f) => f.required).map((f) => f.key);
  // check if form value for the correspodning key is empty, null, undefined or an empty array and then show toast message and return
  for (const key of requiredFlds) {
    if (
      form[key] === "" ||
      form[key] === null ||
      form[key] === undefined ||
      (Array.isArray(form[key]) && form[key].length === 0)
    ) {
      ElMessage({
        message: 'Please fill all required fields',
        type: 'warning',
      })
      return;
    }
  }
  emit("formSubmitted", form);

  for (const key in form) {
    form[key] = emptyForm[key];
  }
};
const onChange = (form, field) => {
  console.log("changed form", form);
  if (field.onChange) {
    const keys = field.onChange.targetField;
    const values = field.onChange.fn(form);
    console.log("keys", keys);
    console.log("values", values);
    for (let i = 0; i < keys.length; i++) {
      form[keys[i]] = values[i];
    }
  }
};

const removeBtnClick = (form) => {
  if (props.schema.removeBtnClicked) {
    const keys = props.schema.removeBtnClicked.targetField;
    const values = props.schema.removeBtnClicked.fn(form);
    console.log("keys", keys);
    console.log("values", values);
    for (let i = 0; i < keys.length; i++) {
      form[keys[i]] = values[i];
    }
  }
};

const uploadAttachments = async (file, key) => {
  console.log("uploadAttachment", file);
  const reader = new FileReader();
  reader.onload = async (e) => {
    const data = e.target.result.split(",");
    const obj = {
      fileName: file.name,
      mimeType: data[0].match(/:(\w.+);/)[1],
      data: data[1],
      uid: file.uid,
    };
    const res = await uploadFile(obj);
    form[key] = form[key].map((obj) =>
      obj.uid === res.uid ? { ...res } : { ...obj }
    );
    // form[key].push({ fileId: fileId, fileName: file.name });
  };
  reader.readAsDataURL(file.raw);
};

const addGroup = (field) => {
  form[field.key].push(getModel(field.fields));
};
const removeGroup = (field, index) => {
  form[field.key].splice(index, 1);
  removeBtnClick(form);
};
</script>

<template>
  <el-form :model="form" label-width="auto" style="max-width: 900px">
    <div v-for="(field, i) in schema.fields.filter((f) => !f.hidden)" :key="i">
      <el-card v-if="field.type === 'groups'" class="box-card mb-2">
        <el-row :gutter="10">
          <el-col :span="fld.span || 6" v-for="(fld, i) in field.fields.filter((f) => !f.hidden)" :key="i">
            {{ fld.label }}
          </el-col>
        </el-row>
        <el-row :gutter="10" v-for="(model, i) in form[field.key]" :key="i">
          <el-col :span="fld.span || 6" v-for="(fld, i) in field.fields.filter((f) => !f.hidden)" :key="i">
            <div v-if="fld.type === 'input'">
              <el-form-item :type="fld.inputType">
                <el-input v-model="model[fld.key]" />
              </el-form-item>
            </div>
            <div v-if="fld.type === 'date'">
              <el-form-item>
                <el-date-picker v-model="model[fld.key]" :type="fld.inputType" placeholder="Pick a date"
                  format="DD/MM/YYYY" />
              </el-form-item>
            </div>
            <div v-if="fld.type === 'datetime'">
              <el-form-item>
                <el-date-picker v-model="model[fld.key]" :type="fld.inputType" placeholder="" format="DD/MM/YYYY HH:mm"
                  date-format="DD/MM/YYYY" time-format="HH:mm" value-format="YYYY-MM-DD HH:mm" />
              </el-form-item>
            </div>
            <div v-if="fld.type === 'time'">
              <el-time-select placeholder="Start time" v-model="model[fld.key]">
              </el-time-select>
            </div>
            <div v-if="fld.type === 'number'">
              <el-form-item v-if="fld.inputType == 'currency'">
                <el-input-number v-model="model[fld.key]" :controls="false" :min="fld.min" :max="fld.max"
                  :disabled="fld.disabled" @change="onChange(form, fld)"
                  :formatter="(value) => `£ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')"
                  :parser="(value) => value.replace(/\£\s?|(,*)/g, '')" />
              </el-form-item>
              <el-form-item v-else>
                <el-input-number v-model="model[fld.key]" :controls="false" :min="fld.min" :max="fld.max"
                  :disabled="fld.disabled" @change="onChange(form, fld)" />
              </el-form-item>
            </div>
            <div v-if="fld.type === 'select'">
              <el-form-item>
                <el-select v-model="form[field.key][fld.key]" placeholder="Select" clearable>
                  <el-option v-for="(item, index) in fld.options" :key="index" :label="item.label || item"
                    :value="item.value || item"></el-option>
                  <template #append>{{ field.append || null }}</template>
                </el-select>
              </el-form-item>
            </div>
            <div v-if="fld.type === 'select_server'">
              <el-form-item>
                <el-select v-model="model[fld.key]" placeholder="Select">
                  <el-option v-for="(item, index) in dd[fld.optionConfig.source]" :key="index"
                    :label="item[fld.optionConfig.label]" :value="item[fld.optionConfig.value]"></el-option>
                </el-select>
              </el-form-item>
            </div>
          </el-col>
          <el-button @click="removeGroup(field, i)" type="danger">
            X
          </el-button>
        </el-row>

        <el-button @click="addGroup(field)" type="primary">+ Add</el-button>
      </el-card>
      <div v-if="field.type === 'input'">
        <el-form-item :label="`${field.label}${field.required ? ' *' : ''}`" :type="field.inputType">
          <el-input v-model="form[field.key]" />
        </el-form-item>
      </div>
      <div v-if="field.type === 'date'">
        <el-form-item :label="`${field.label}${field.required ? ' *' : ''}`">
          <el-date-picker v-model="form[field.key]" :type="field.inputType" placeholder="Pick a date"
            format="DD/MM/YYYY" />
        </el-form-item>
      </div>
      <div v-if="field.type === 'month'">
        <el-form-item :label="`${field.label}${field.required ? ' *' : ''}`">
          <el-date-picker v-model="form[field.key]" type="month" placeholder="Pick a month" format="MMM YYYYY" />
        </el-form-item>
      </div>
      <div v-if="field.type === 'datetime'">
        <el-form-item :label="`${field.label}${field.required ? ' *' : ''}`">
          <el-date-picker v-model="form[field.key]" :type="field.inputType" placeholder="" format="DD/MM/YYYY HH:mm"
            date-format="DD/MM/YYYY" time-format="HH:mm" value-format="YYYY-MM-DD HH:mm" />
        </el-form-item>
      </div>
      <div v-if="field.type === 'time'">
        <el-form-item :label="`${field.label}${field.required ? ' *' : ''}`">
          <el-time-select placeholder="Start time" v-model="form[field.key]">
          </el-time-select>
        </el-form-item>
      </div>
      <div v-if="field.type === 'number'">
        <el-form-item :label="`${field.label}${field.required ? ' *' : ''}`">
          <el-input-number v-model="form[field.key]" :controls="false" :min="field.min" :max="field.max"
            @change="onChange(form, field)">
          </el-input-number>
        </el-form-item>
      </div>
      <div v-if="field.type === 'files'">
        <!-- <el-upload v-model:file-list="form[field.key]" class="upload-demo" :auto-upload="false" list-type="picture-card"
          multiple :on-change="(file, files) => {
    uploadAttachments(file, field.key)
  }">
          <el-button type="primary">Click to upload</el-button>
          <template #tip>
            <div class="el-upload__tip">
              jpg/png files with a size less than 500KB.
            </div>
          </template>
</el-upload> -->

        <el-form-item :label="`${field.label}${field.required ? ' *' : ''}`" :type="field.inputType">
          <el-upload v-model:file-list="form[field.key]" class="upload-demo" :auto-upload="false" multiple
            list-type="picture-card" :on-change="(file, files) => {
    uploadAttachments(file, field.key);
  }
    ">
            <el-icon>
              <i-ep-plus />
            </el-icon>
          </el-upload>
        </el-form-item>
      </div>
      <div v-if="field.type === 'select'">
        <el-form-item :label="`${field.label}${field.required ? ' *' : ''}`">
          <el-select v-model="form[field.key]" placeholder="Select" clearable>
            <el-option v-for="(item, index) in field.options" :key="index" :label="item.label || item"
              :value="item.value || item"></el-option>

          </el-select>
        </el-form-item>
      </div>
      <div v-if="field.type === 'select_server'">
        <el-form-item :label="`${field.label}${field.required ? ' *' : ''}`">
          <el-select v-model="form[field.key]" placeholder="Select" clearable>
            <el-option v-for="(item, index) in dd[field.optionConfig.source]" :key="index"
              :label="item[field.optionConfig.label]" :value="item[field.optionConfig.value]"></el-option>
          </el-select>
        </el-form-item>
      </div>
    </div>
    <el-form-item>
      <el-button type="primary" @click="onSubmit" :disabled="uploading || submitting">Submit</el-button>
      <el-button @click="() => {
    emit('formCancelled');
  }">Cancel</el-button>
    </el-form-item>
  </el-form>
  <!-- <pre style="font-size: 9px">
  {{ form }}
</pre
  > -->
</template>

<style scoped>
.box-card {
  width: 100%;
  background: rgb(244, 253, 255);
}
</style>
