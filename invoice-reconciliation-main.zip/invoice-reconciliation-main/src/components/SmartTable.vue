<script setup lang="jsx">
import SmartForm from "~/components/SmartForm.vue";
import SmartDetail from "~/components/SmartDetail.vue";
import { getModel, allSchemas } from "~/schema";
import { reactive, ref, onMounted, computed } from "vue";
import { useRoute } from "vue-router";
import { useAppStore } from "~/stores/appStore";
import { extractLastPathName, camelCaseToTitleCase } from "~/helpers";
import { ElPopconfirm } from "element-plus";
import { ElButton, ElIcon } from "element-plus";
import {
  Plus,
  CopyDocument,
  Delete,
  View,
  Edit,
} from "@element-plus/icons-vue";
import { TableV2SortOrder } from "element-plus";

const props = defineProps({
  defaultFormValues: {
    type: Object,
    required: false,
  },
});

const route = useRoute();
const sheetName = camelCaseToTitleCase(extractLastPathName(route.fullPath));
const schema = allSchemas.find((s) => s.sheetName === sheetName);
console.log("sheetName", sheetName);
const actionFormDialog = ref({

})
const dialogFormVisible = ref(false);
const dialogDetailVisible = ref(false);
const loading = computed(() => appStore.loading);
const actionModalObject = ref({
  visible: false,
  formVisible: false,
  form: null,
  action: null,
  sheetName: null,
  schema: null,
  initialValues: null,
  editId: null,
});
let form = null;
let editId = null;

const appStore = useAppStore();
const { tables, indexedTables, chooseAndRunAction, sort } =
  appStore;

const emit = defineEmits(["formEdited", "formDeleted"]);
const showCrudBtn = computed(() => appStore.isAdmin || !!!schema.editPrevent);

const submitForm = async (formData, sheetName, id = null) => {
  console.log("submit", formData);
  //loading.value = true;
  await appStore.addRow(sheetName, formData, id);
  //loading.value = false;
  editId = null;
  actionModalObject.value.editId = null;
  if (schema.defaultSort) {
    onSort({ key: schema.defaultSort.key, order: schema.defaultSort.order });
  }
};
const addNew =
  (f) =>
    (initialValues = null) => {
      dialogFormVisible = true;
      dialogFormVisible.value = true;
      form = { ...f };
    };

const handleEdit =
  (f, id, schema, inNestedModal = false) =>
    () => {
      if (inNestedModal) {
        actionModalObject.value = {
          visible: true,
          formVisible: true,
          form: f,
          action: "update",
          sheetName: schema.sheetName,
          schema: schema,
          initialValues: null,
          editId: id,
        };
      } else {
        console.log("edit", f);
        dialogFormVisible.value = true;
        form = { ...f };
        editId = id;
      }
    };

const handleDelete = (key, schema) => async () => {
  // console.log("delete", key);

  ElMessageBox.confirm(
    'This will delete the selected row. Continue?',
    'Warning',
    {
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel',
      type: 'warning',
    }
  )
    .then(async () => {
      //loading.value = true;
      await appStore.deleteRow(schema.sheetName, key);
      //loading.value = false;
    })
    .catch(() => {
      ElMessage({
        type: 'info',
        message: 'Delete canceled',
      })
    })


};

const handleDetail = (f) => () => {
  console.log("detail", f);
  dialogDetailVisible.value = true;
  form = { ...f };
};

const duplicateRow = (key, schema) => async () => {
  console.log("duplicate", key);
  //loading.value = true;
  await appStore.duplicateRow(schema.sheetName, key);
  //loading.value = false;
};

const columnGenerator = (schema, inNestedModal = false) => {
  const cols = schema.fields.map((c) => {
    if (c.type === "select_server") {
      return {
        key: c.key,
        dataKey: c.key,
        title: c.label,
        width: c.colWidth || 150,
        sortable: c.sort ? true : false,
        cellRenderer: ({ cellData: key }) => {
          if (!key) return "NA";
          return indexedTables[c.optionConfig.source][key][c.optionConfig.label]
        }
      };
    }
    if (c.type === "groups") {
      return {
        key: c.key,
        dataKey: c.key,
        title: c.label,
        width: c.colWidth || 150,
        cellRenderer: ({ cellData: arr }) => `Total Entries: ${arr.length}`,
      };
    }

    return {
      key: c.key,
      dataKey: c.key,
      title: c.label,
      width: c.colWidth || 150,
      cellRenderer: c.cellRenderer,
      sortable: c.sort ? true : false,
    };
  });
  cols.push({
    key: "actions",
    title: "Actions",
    cellRenderer: ({ rowData: { form: f, id: key } }) => (
      <>
        <ElButton size="medium" type="text" onClick={handleDetail(f)}>
          <ElIcon>
            <View />
          </ElIcon>
        </ElButton>
        <>
          {showCrudBtn && (
            <ElButton
              size="medium"
              type="text"
              onClick={handleEdit(f, key, schema, inNestedModal)}
            >
              <ElIcon>
                <Edit />
              </ElIcon>
            </ElButton>
          )}</>

        <>
          {schema.duplicateButton && (
            <ElButton
              size="medium"
              type="text"
              onClick={duplicateRow(key, schema)}
            >
              <ElIcon>
                <CopyDocument />
              </ElIcon>
            </ElButton>
          )}
        </>
        <>
          {showCrudBtn && (
            <ElButton size="medium" type="text" onClick={handleDelete(key, schema)}>
              <ElIcon>
                <Delete />
              </ElIcon>
            </ElButton>
          )}</>

      </>
    ),
    width: 250,
    align: "center",
  });
  return cols;
};
const columns = columnGenerator(schema);

let data = computed(() => {
  return tables[sheetName].map((data) => {
    data.children = [
      {
        id: `${data.id}-detail-content`,
        detail: "detailedText",
        form: data.form,
        editId: data.id,
      },
    ];
    return data;
  });
});

const sortState = ref({});
schema.fields.forEach((f) => {
  if (f.sort) {
    sortState.value[f.key] = TableV2SortOrder.ASC;
  }
});

const onSort = ({ key, order }) => {
  // console.log("sort", key, order);
  sortState.value[key] = order;
  // console.log("sortState order:", order);
  sort(sheetName, key, order);
};
if (schema.defaultSort) {
  onSort({ key: schema.defaultSort.key, order: schema.defaultSort.order });
}



const Row = ({ cells, rowData }) => {
  if (rowData.detail) {
    let buttons1 = null;
    let buttons2 = null;
    let buttons3 = null;
    if (schema.actionButtons && showCrudBtn) {
      buttons1 = (
        <td>
          {schema.actionButtons
            .filter((b) => b.actionType !== "modal" && b.actionType !== "dialogForm")
            .map((button) => (
              <ElButton
                size="small"
                type={button.type}
                onClick={() =>
                  chooseAndRunAction(
                    sheetName,
                    rowData.form,
                    rowData.editId,
                    button.action
                  )
                }
              >
                {button.label}
              </ElButton>
            ))}
        </td>
      );
      buttons2 = (
        <td>
          {schema.actionButtons
            .filter((b) => b.actionType === "modal")
            .map((button) => (
              <ElButton
                size="small"
                type={button.type}
                onClick={() => {
                  const schema = allSchemas.find(
                    (s) => s.sheetName === button.sheetName
                  );
                  actionModalObject.value = {
                    visible: true,
                    form: null,
                    action: button.action,
                    sheetName: button.sheetName,
                    schema: schema,
                    initialValues: schema.getDefaultFormValues(rowData) || null,
                  };
                }}
              >
                {button.label}
              </ElButton>
            ))}
        </td>
      );
      buttons3 = (
        <td>
          {schema.actionButtons
            .filter((b) => b.actionType === "dialogForm")
            .map((button) => (
              <ElButton
                size="small"
                type={button.type}
                onClick={() => {
                }}
              >
                {button.label}
              </ElButton>
            ))}
        </td>
      );
    }
    return (
      <div class="p-6">
        {buttons1}
        {buttons2}
        {buttons3}
      </div>
    );
  }
  return cells;
};
Row.inheritAttrs = false;
</script>

<template>
  <el-row justify="space-between">
    <el-col :span="4" class="align-left">
      <el-text tag="b">
        {{ schema.title }}
        <el-button plain @click="dialogFormVisible = true" type="primary" class="ml-4" v-if="showCrudBtn"> + Add
        </el-button>
      </el-text>
    </el-col>
    <el-col :span="6">
      <el-dropdown v-if="schema.fab">
        <el-button type="primary" v-if="showCrudBtn">
          More Actions<el-icon class="el-icon--right"><arrow-down /></el-icon>
        </el-button>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item v-for="(btn, i) in schema.fab" :key="i">
              <el-button size="small" class="m-2" @click="chooseAndRunAction(schema.sheetName, data, null, btn.action)">
                {{ btn.label }}
              </el-button>
            </el-dropdown-item>

          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </el-col>
  </el-row>


  <el-dialog v-model="dialogFormVisible" v-loading="loading" :title="schema.sheetName" @close="form = null"
    :fullscreen="schema?.fullscreen || false">
    <SmartForm :schema="schema" :form="form" @formCancelled="() => {
      form = null;
      dialogFormVisible = false;

    }" @formSubmitted="(formData) => {
      submitForm(formData, schema.sheetName, editId);
      dialogFormVisible = false;
    }
      " :dd="tables" :key="editId || 'null'" :initialValues="defaultFormValues" />
  </el-dialog>
  <el-table-v2 v-loading="loading" v-model:sort-state="sortState" :columns="columns" :data="data || []" fixed
    :width="schema.tableWidth || 1420" :height="580" :expand-column-key="schema.actionButtons ? columns[0].key : null"
    @column-sort="onSort" :row-height="40">
    <template #row="props">
      <Row v-bind="props" />
    </template>
  </el-table-v2>
  <el-dialog v-model="actionModalObject.visible" :title="actionModalObject.sheetName" width="800"
    @close="actionModalObject.form = null">
    <el-button plain @click="actionModalObject.formVisible = true">
      + Add
    </el-button>

    <el-dialog v-model="actionModalObject.formVisible" :title="actionModalObject.sheetName" width="500"
      :fullscreen="true" @close="actionModalObject.form = null">
      <SmartForm :schema="actionModalObject.schema" :form="actionModalObject.form"
        :initialValues="actionModalObject.initialValues" @formCancelled="() => {
      actionModalObject.form = null;
      dialogFormVisible = false;
    }" @formSubmitted="(formData) => {
      submitForm(
        formData,
        actionModalObject.sheetName,
        actionModalObject.editId
      );
      dialogFormVisible = false;
    }
      " :dd="tables" :key="actionModalObject.editId || 'null'" />
    </el-dialog>
    <el-table-v2 :columns="columnGenerator(actionModalObject.schema, true)"
      :data="tables[actionModalObject.sheetName] || []" fixed :width="500" :height="580"
      :expand-column-key="columns[0].key">
      <!-- <template #row="props">
        <Row v-bind="props" />
      </template> -->
    </el-table-v2>
  </el-dialog>
  <el-dialog v-model="dialogDetailVisible" :title="schema.titleDetailView || schema.sheetName" :fullscreen="false"
    @close="form = null">
    <SmartDetail :schema="schema" :form="form" :dd="indexedTables" />
  </el-dialog>

  <!-- WhatsApp Dialog -->
  <el-dialog v-model="dialogActionFormVisible" title="Shipping address" width="500">
    <el-form :model="actionForm">
      <el-form-item label="Message" type="textarea">
        <el-input v-model="actionForm.message" autocomplete="off" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible = false">Cancel</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">
          Confirm
        </el-button>
      </div>
    </template>
  </el-dialog>

  <!-- Send Email Dialog -->
  <el-dialog v-model="dialogActionFormVisible" title="Shipping address" width="500">
    <el-form :model="actionForm">
      <el-form-item label="Subject">
        <el-input v-model="actionForm.subject" />
      </el-form-item>
      <el-form-item label="Body">
        <el-input v-model="actionForm.body" type="textarea" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible = false">Cancel</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">
          Confirm
        </el-button>
      </div>
    </template>
  </el-dialog>

</template>

<style>
.el-table-v2__row-depth-0 {
  height: 40px;
}

.el-table-v2__cell-text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.el-table-v2 {
  font-size: 11px;
}

/* reduce row height of table */
.el-table-v2__row {
  height: 40px;
}

/* show scrollbar */
.el-table-v2__body-wrapper {
  overflow-y: auto;
}
</style>
