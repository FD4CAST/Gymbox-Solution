//  Json array from 2 da array considering 1st row as header

export const jsonFrom2DArray = (arr) => {
  const [header, ...rows] = arr;
  return rows.map((row) =>
    row.reduce((acc, cell, i) => {
      acc[header[i]] = cell;
      return acc;
    }, {})
  );
};

export const camelCaseToTitleCase = (text) => {
  let result = text.replace(/([A-Z])/g, " $1");
  result = result.charAt(0).toUpperCase() + result.slice(1);
  return result;
};

/**
 * Extracts the last path name from a given full path.
 *
 * @param {string} fullPathName - The full path name containing multiple path segments separated by '/'.
 * @returns {string} The last path name segment extracted from the full path.
 */
export function extractLastPathName(fullPathName) {
  const parts = fullPathName.split("/");
  const lastWord = parts[parts.length - 1];
  return lastWord;
}

export const process2Darray = (res) => {
  console.log("helpers | process2Darray:- ", res);
  const parsedTables = JSON.parse(res);
  Object.keys(parsedTables).forEach((key) => {
    let tbl = jsonFrom2DArray(parsedTables[key]);
    tbl = tbl.map((row) => {
      row.form = JSON.parse(row.form);
      return { id: row.id, ...row.form };
    });
    indexedTables.value[key] = tbl.reduce((acc, row) => {
      acc[row.id] = row;
      return acc;
    }, {});
    tables.value[key] = tbl;
  });
};

export const formatDateString = (dateString) => {
  var dateObject = new Date(dateString);
  var year = dateObject.getFullYear();
  var month = String(dateObject.getMonth() + 1).padStart(2, "0");
  var day = String(dateObject.getDate()).padStart(2, "0");
  var hours = String(dateObject.getHours()).padStart(2, "0");
  var minutes = String(dateObject.getMinutes()).padStart(2, "0");
  var formattedDate =
    year + "-" + month + "-" + day + " " + hours + ":" + minutes;
  return formattedDate;
};

export const toMonth = (dateString) => {
  var dateObject = new Date(dateString);
  var year = dateObject.getFullYear();
  var month = String(dateObject.getMonth() + 1).padStart(2, "0");
  var day = String(1).padStart(2, "0");
  var formattedDate = year + "-" + month + "-" + day;
  return formattedDate;
};

export const getDatesOfPreviousWeek = (dt = new Date()) => {
  let dates = [];
  let startDate = dt;
  startDate.setDate(startDate.getDate() - startDate.getDay() - 6);
  let endDate = new Date(startDate);
  endDate.setDate(endDate.getDate() + 6);
  let sundayDate = new Date(startDate);
  let sundayFormattedDate = sundayDate.toISOString().split("T")[0];
  dates.push(sundayFormattedDate);
  let saturdayDate = new Date(endDate);
  let saturdayFormattedDate = saturdayDate.toISOString().split("T")[0];
  dates.push(saturdayFormattedDate);
  return dates;
};

export const getDatesOfCurrentWeek = (dt = new Date()) => {
  let dates = [];
  let startDate = dt;
  startDate.setDate(startDate.getDate() - startDate.getDay() + 1);
  let endDate = new Date(startDate);
  endDate.setDate(endDate.getDate() + 6);
  let sundayDate = new Date(startDate);
  let sundayFormattedDate = sundayDate.toISOString().split("T")[0];
  dates.push(sundayFormattedDate);
  let saturdayDate = new Date(endDate);
  let saturdayFormattedDate = saturdayDate.toISOString().split("T")[0];
  dates.push(saturdayFormattedDate);
  return dates;
};
function getOrdinalSuffix(day) {
  if (day > 3 && day < 21) return "th"; // All the days from 4th to 20th have "th"
  switch (day % 10) {
    case 1:
      return "st";
    case 2:
      return "nd";
    case 3:
      return "rd";
    default:
      return "th";
  }
}

export function formatDateWithOrdinalSuffix(date) {
  const day = date.getDate();
  const monthFormatter = new Intl.DateTimeFormat("en-US", { month: "short" });
  const yearFormatter = new Intl.DateTimeFormat("en-US", { year: "numeric" });

  const dayWithSuffix = day + getOrdinalSuffix(day);
  const month = monthFormatter.format(date);
  const year = yearFormatter.format(date);

  return `${dayWithSuffix} ${month} ${year}`;
}

export const gymBoxRates = {
  30: 17.5,
  45: 35,
  60: 35,
  90: 52.5,
  120: 120,
};
export function maskString(input, unmaskedLength = 4) {
  if (typeof input !== "string") {
    throw new Error("Input must be a string");
  }
  if (unmaskedLength > input.length) {
    unmaskedLength = input.length;
  }

  const maskedLength = input.length - unmaskedLength;

  const maskedPart = "X".repeat(maskedLength);

  const unmaskedPart = input.slice(-unmaskedLength);

  if (/[^0-9]/.test(input)) {
    let maskedInput = input
      .split("")
      .map((char, index) => {
        return /\d/.test(char) && index < maskedLength ? "X" : char;
      })
      .join("");
    return maskedInput;
  }

  return maskedPart + unmaskedPart;
}
export const formatDateToMMYY = () => {
  let currentDate = new Date();
  let month = currentDate.getMonth();
  currentDate.setMonth(month - 1);
  let formattedDate =
    currentDate.getFullYear().toString().slice(-2) +
    (currentDate.getMonth() + 1).toString().padStart(2, "0");
  return formattedDate;
};

export function getREFNo(name, month) {
  if (!name) {
    return "";
  }
  const parts = name.split(" ");
  const firstName = parts[0];
  const lastName = parts.length > 1 ? parts[1] : "";
  let formattedName;
  if (lastName) {
    formattedName = (firstName[0] + lastName.slice(0, 3)).toUpperCase();
  } else {
    formattedName = firstName.slice(0, 4).toUpperCase();
  }
  const [y, m, d] = month.split("-");
  const monthString = `${m}${y.slice(2)}`;

  return formattedName + monthString;
}

export const companyInfo = {
  name: "Elite Combat Agency",
  address: "68 Grosvenor Road, Tunbridge Wells,England,TN1 2AS",
  registrationNumber: "10323962",
  VAT: "296 8016 66",
  bankName: "Metro",
  bankAcc: "40557919",
  sortCode: "20-62-69",
  email: "elitecombatagency@hotmail.com",
  remittanceAdvice: {
    refPrefix: "ALAM",
  },
  invoicePrefix: "EL",
  logo: "https://i.ibb.co/thTrDY1/Whats-App-Image-2024-05-24-at-5-48-54-PM.jpg",
  gymBoxRates: gymBoxRates,
};

export const driveImageURL = (id) => {
  return `https://drive.google.com/thumbnail?id=${id}&sz=w1000`;
};

export const colorTypes = {
  Pending: "warning",
  Completed: "success",
  Cancelled: "danger",
  Refunded: "info",
  Failed: "danger",
  Active: "success",
  Inactive: "danger",
  Suspended: "warning",
  Expired: "danger",
  Paid: "success",
  Unpaid: "warning",
  "Partially Paid": "info",
  Overdue: "danger",
  No: "danger",
  Approved: "success",
  "Not Received": "warning",
};
