<script setup>
import { RouterLink, RouterView, useRouter } from 'vue-router'
import { computed } from 'vue'

import BaseSide from './components/layouts/BaseSide.vue'
import { useAppStore } from '~/stores/appStore'

const loggedUserData = JSON.parse(
  document.getElementById("loggedUser").innerHTML
);


const router = useRouter();
const appStore = useAppStore();

const loading = computed(() => appStore.appIsLoading);

appStore.fetchTables(loggedUserData);

watch(loading, (val) => {
  if (!val) {
    router.push({ name: 'classes' })
  }
})


</script>

<template>
  <BaseSide />
  <el-tag v-if="loading" type="warning" style="margin:40px;padding:30px;font-size: 30px;">Loading ...</el-tag>
  <div w="full" py="4" px="4">
    <RouterView :key="$route.fullPath" />
  </div>
</template>


<style>
#app {
  text-align: center;
  color: var(--ep-text-color-primary);
}

.main-container {
  height: calc(100vh - var(--ep-menu-item-height) - 3px);
}
</style>