import { ref, computed } from "vue";
import { defineStore } from "pinia";
import { jsonFrom2DArray, getDatesOfPreviousWeek } from "~/helpers";
import { executeAction } from "~/services";
import { allSheetNames } from "~/schema";
import dayjs from "dayjs";
import duration from "dayjs/plugin/duration";
import isBetween from "dayjs/plugin/isBetween";
import { ElMessage, ElMessageBox } from "element-plus";
dayjs.extend(duration);
dayjs.extend(isBetween);

export const useAppStore = defineStore("appStore", () => {
  const tables = ref({});
  const indexedTables = ref({});
  const loading = ref(false);
  const appIsLoading = ref(true);
  const isAdmin = ref(true);
  const loggedUser = ref(null);
  const selectedRemittanceRow = ref(null);
  const selectedInvoiceRow = ref(null);
  const scriptURL = ref(null);

  const USER_TBL_NAME = "Coaches";
  const fetchingAllTables = ref(false);

  const loggedInstructorName = computed(() => {
    if (loggedUser?.value) {
      const user = indexedTables.value[USER_TBL_NAME][loggedUser.value.id];
      return user?.name;
    }
    return null;
  });

  const nextInvoiceNumber = computed(() => {
    const invoices = tables.value["Amount Received"];
    const lastInvoice = invoices[invoices.length - 1];
    return lastInvoice ? lastInvoice.form.invoiceNumber + 1 : 1;
  });

  const tablesHavingDependentKeys = {
    Coaches: ["Invoices Received", "Fine Entries", "Instructor Entries"],
    Gyms: ["Instructor Entries", "Fine Entries"],
    "Classes Taught": ["Instructor Entries", "Fine Entries"],
  };
  const FEW_SHEET_NAMES = [
    "Coaches",
    "Gyms",
    "Instructor Entries",
    "Classes Taught",
  ];

  // const getScriptURL = () => {
  //   google.script.run
  //     .withSuccessHandler((res) => {
  //       console.log("scriptURL:- ", res);
  //       scriptURL.value = res;
  //     })
  //     .scriptURL();
  // };
  const fetchTables = async (loggedUserData) => {
    console.log("fetchTables | loggedUser:- ", loggedUserData);
    const userStringified = loggedUserData?.user;
    isAdmin.value = loggedUserData?.isAdmin;
    loggedUser.value = userStringified ? JSON.parse(userStringified) : null;
    const sheetNames = loggedUserData.isAdmin ? allSheetNames : FEW_SHEET_NAMES;
    google.script.run
      .withSuccessHandler((res) => {
        fetchingAllTables.value = false;
        process2Darray(res);
        appIsLoading.value = false;
      })
      .withFailureHandler((error) => {
        console.log(error);
      })
      .getStringiFiedTables(sheetNames);
  };

  const getTable = (sheetName) => {
    // return tables.value[sheetName];
    return tables.value[sheetName].map((data) => {
      data.children = [
        {
          id: `${data.id}-detail-content`,
          detail: "detailedText",
          form: data.form,
          editId: data.id,
        },
      ];
      return data;
    });
  };

  const addRow = async (sheetName, form, id = null) => {
    const action = id ? "update" : "add";
    if (action === "add") {
      if (!doAdditionalChecks(sheetName, form)) {
        return;
      }
    }

    loading.value = true;
    const res = await executeAction({
      action: action,
      sheetName: sheetName,
      data: { form: JSON.stringify(form), id: id },
      id: id,
    });
    loading.value = false;
    // console.log(res);
    process2Darray(res);
    ElMessage.success("Record saved successfully.");
  };

  const duplicateRow = async (sheetName, id) => {
    loading.value = true;
    const res = await executeAction({
      action: "duplicate",
      sheetName: sheetName,
      id: id,
    });
    // console.log(res);
    loading.value = false;
    process2Darray(res);
  };
  const duplicatePreviousWeekSchedule = async (sheetName, data, actionName) => {
    loading.value = true;
    const previousWeekDates = getDatesOfPreviousWeek();
    console.log("previousWeekDates:- ", previousWeekDates);
    const filteredData = data
      .filter(({ form }) => {
        console.log("form.date:- ", form.date);
        const entryDate = dayjs(form.date);
        console.log("entryDate:- ", entryDate);
        return entryDate.isBetween(previousWeekDates[0], previousWeekDates[1]);
      })
      .map(({ form }) => {
        form.date = dayjs(form.date).add(1, "week").format("YYYY-MM-DD");
        form.status = "Pending";
        return { form: JSON.stringify(form), id: null };
      });
    console.log("filteredData:- ", filteredData);

    const res = await executeAction({
      action: "bulkAdd",
      sheetName: sheetName,
      data: filteredData,
    });
    loading.value = false;
    process2Darray(res);
  };

  const deleteRow = async (sheetName, id) => {
    loading.value = true;
    if (!checkIfRecordCanBeDeleted(sheetName, id)) {
      loading.value = false;

      ElMessage.error(
        "Record cannot be deleted as it is being used in other tables"
      );
      return;
    }

    const res = await executeAction({
      action: "delete",
      sheetName: sheetName,
      id: id,
    });
    // console.log(res);
    loading.value = false;
    process2Darray(res);
  };

  const chooseAndRunAction = (sheetName, data, id, actionName) => {
    console.log("chooseAndRunAction | data:- ", data);

    switch (actionName) {
      case "markComplete":
        markComplete(sheetName, data, id);
        break;
      case "markCompleteAndRecreate":
        markCompleteAndRecreate(sheetName, data, id);
        break;
      case "duplicatePreviousWeekSchedule":
        duplicatePreviousWeekSchedule(sheetName, data, actionName);
        break;
      case "generateRemittanceAdvice":
        generateRemittanceAdvice(sheetName, data, id);
        break;
      case "sendRemittanceAdvice":
        sendRemittanceAdvice(data, sheetName);
        break;
      case "sendInvoiceRequestEmails":
        sendInvoiceRequestEmails();
        break;
      case "sendInvoiceRequestEmail":
        sendInvoiceRequestEmail(data);
        break;
      case "openWhatsappweb":
        openWhatsappweb(data);
        break;
      case "sendInvoiceRequestWhatsApp":
        sendInvoiceRequestWhatsApp();
        break;

      case "sendInvoice":
        sendInvoice(data, sheetName);
        break;
      case "sendAccessURL":
        sendAccessURL(data);
        break;
      default:
        console.log("No action found");
    }
  };
  const generateRemittanceAdvice = async (sheetName, row, id) => {
    console.log("generateRemittanceAdvice:- ", row);
    return;
    form.status = [
      {
        remittanceGenerated: true,
        on: new Date(),
      },
      {
        remittanceAdviceSent: false,
        on: null,
      },
      {
        amountPaid: false,
        on: null,
      },
    ];

    loading.value = true;
    form.status = "Completed";
    const res = await executeAction({
      action: "update",
      sheetName: sheetName,
      id: id,
      data: { form: JSON.stringify(form), id: id },
    });
    loading.value = false;
    process2Darray(res);
  };

  const markComplete = async (sheetName, form, id) => {
    loading.value = true;
    form.status = "Completed";
    const res = await executeAction({
      action: "update",
      sheetName: sheetName,
      id: id,
      data: { form: JSON.stringify(form), id: id },
    });
    loading.value = false;
    process2Darray(res);
  };

  const markCompleteAndRecreate = async (sheetName, form, id) => {
    form.status = "Completed";
    loading.value = true;
    const deadline_date = dayjs(form.deadline_date);
    const periodicityID = form.periodicity;
    const periodicity = indexedTables.value["Periodicities"][periodicityID];
    console.log("periodicity:- ", periodicity);

    executeAction({
      action: "update",
      sheetName: sheetName,
      id: id,
      data: { form: JSON.stringify(form), id: id },
    });

    const newTask = {
      ...form,
      deadline_date: dayjs(deadline_date).add(
        dayjs.duration({
          days: periodicity.Days,
          months: periodicity.Months,
          years: periodicity.Years,
        })
      ),
      status: "Pending",
    };
    const res = await executeAction({
      action: "add",
      sheetName: sheetName,
      id: id,
      data: { form: JSON.stringify(newTask), id: null },
    });
    loading.value = false;
    process2Darray(res);
  };

  const selectRemittanceRow = (month, coach) => {
    const remittancesTable = tables.value["Remittances Sent"];
    const found = remittancesTable.find(
      (item) => item.month == month && item.coach == coach
    );
    selectedRemittanceRow.value = found;
  };

  const selectInvoiceRow = (month, gym) => {
    const invoicesTable = tables.value["Amount Received"];
    const found = invoicesTable.find(
      (item) => item.month == month && item.gym == gym
    );
    selectedInvoiceRow.value = found;
  };

  const savePDF = async (obj, payload, folder) => {
    loading.value = true;
    google.script.run
      .withSuccessHandler((res) => {
        console.log("Uploaded File url", res);
        process2Darray(res);
        if (folder === "Invoices")
          selectInvoiceRow(payload.form.month, payload.form.gym);
        if (folder === "Remittance Advices")
          selectRemittanceRow(payload.form.month, payload.form.coach);
        loading.value = false;
        ElMessage.success("PDF saved and record created successfully.");
      })
      .savePDF(obj, JSON.stringify(payload), folder); // Invoices is PDF name
  };

  const sendInvoice = async (data, sheetName) => {
    loading.value = true;
    const payload = {
      form: data.form,
      sheetName: data.sheetName,
      id: data.id || null,
      action: "update",
      selectedGym: data.selectedGym,
    };
    google.script.run
      .withSuccessHandler((res) => {
        console.log("Invoice Sent", res);
        process2Darray(res);
        selectInvoiceRow(payload.form.month, payload.form.gym);
        loading.value = false;
        ElMessage.success("Invoice sent successfully.");
      })
      .sendInvoice(JSON.stringify(payload));
  };
  const sendRemittanceAdvice = async (data, sheetName) => {
    loading.value = true;
    const payload = {
      form: data.form,
      sheetName: data.sheetName,
      id: data.id || null,
      action: "update",
      selectedCoach: data.selectedCoach,
    };
    console.log("sendRemittanceAdvice:- ", payload);
    google.script.run
      .withSuccessHandler((res) => {
        console.log("Remittance Sent", res);
        process2Darray(res);
        selectRemittanceRow(payload.form.month, payload.form.coach);
        loading.value = false;
        ElMessage.success("Remittance advice sent successfully.");
      })
      .sendRemittanceAdvice(JSON.stringify(payload));
  };

  const sendAccessURL = (data) => {
    loading.value = true;
    google.script.run
      .withSuccessHandler((res) => {
        console.log("Access URL Sent", res);
        loading.value = false;
        ElMessage.success("Access URL Sent successfully.");
      })
      .sendAccessURL(data);
  };
  const sendInvoiceRequestEmails = () => {
    const instructors = tables.value["Coaches"]
      .filter((c) => c.status == "Active")
      .map((c) => {
        return {
          name: c.name,
          email: c.email,
        };
      });
    ElMessageBox.confirm(
      "This action will send Invoice Request Emails to all the active instructors. Are you sure you want to send Invoice Request Emails?",
      "Warning",
      {
        confirmButtonText: "OK",
        cancelButtonText: "Cancel",
        type: "warning",
      }
    )
      .then(() => {
        loading.value = true;
        google.script.run
          .withSuccessHandler((res) => {
            console.log("Invoice Request Emails Sent", res);
            loading.value = false;
            ElMessage.success("Invoice Request Emails Sent successfully.");
          })
          .sendInvoiceRequestEmails(instructors);
      })
      .catch(() => {
        loading.value = false;
      });
  };
  const sendInvoiceRequestEmail = (data) => {
    console.log("sendInvoiceRequestEmail:- ", data);
    const instructors = [{ name: data.name, email: data.email }];
    ElMessageBox.confirm(
      "This action will send Invoice Request Email to the selected instructor. Are you sure you want to send Invoice Request Email?",
      "Warning",
      {
        confirmButtonText: "OK",
        cancelButtonText: "Cancel",
        type: "warning",
      }
    )
      .then(() => {
        loading.value = true;
        google.script.run
          .withSuccessHandler((res) => {
            console.log("Invoice Request Emails Sent", res);
            loading.value = false;
            ElMessage.success("Invoice Request Email Sent successfully.");
          })
          .sendInvoiceRequestEmails(instructors);
      })
      .catch(() => {
        loading.value = false;
      });
  };

  const sendInvoiceRequestWhatsApp = () => {
    loading.value = true;
    const instructors = tables.value["Coaches"]
      .filter((c) => c.status == "Active")
      .map((c) => {
        return {
          name: c.name,
          phone: c.phone,
        };
      });
    console.log("sendInvoiceRequestWhatsApp|instructors:- ", instructors);
    ElMessageBox.confirm(
      "This action will send Invoice Request Emails to all the active instructors. Are you sure you want to send Invoice Request Emails?",
      "Warning",
      {
        confirmButtonText: "OK",
        cancelButtonText: "Cancel",
        type: "warning",
      }
    )
      .then(() => {
        google.script.run
          .withSuccessHandler((res) => {
            console.log("Invoice Request Emails Sent", res);
            loading.value = false;
            ElMessage.success("Invoice Request Emails Sent successfully.");
          })
          .sendInvoiceRequestEmails(instructors);
      })
      .catch(() => {
        loading.value = false;
      });
  };

  const openWhatsappweb = ({ phone }) => {
    let dt = new Date();
    dt.setMonth(dt.getMonth() - 1);
    const month = dt.toLocaleString("default", {
      month: "short",
      year: "numeric",
    });
    // const phone = "917003942355";
    const message = `Elite Combat Agency requires your invoice for the month of ${month}. Please submit your invoice by the final day of the month.`;
    const url = `https://wa.me/${phone}?text=${message}`;
    window.open(url, "_blank");
  };
  // helper methods:
  const process2Darray = (res) => {
    // console.log("helpers | process2Darray:- ", res);
    const parsedTables = JSON.parse(res);
    // Add Extra tbl for covers if Coaches is present
    if (parsedTables["Coaches"])
      parsedTables["Covers"] = parsedTables["Coaches"];

    Object.keys(parsedTables).forEach((key) => {
      let tbl = jsonFrom2DArray(parsedTables[key]);
      tbl = tbl.map((row) => {
        row.form = JSON.parse(row.form);
        return { ...row, ...row.form };
      });
      if (loggedUser?.value?.id) {
        if (key === USER_TBL_NAME) {
          tbl = tbl.filter((row) => row.id == loggedUser.value.id);
        }
        if (key === "Instructor Entries") {
          tbl = tbl.filter((row) => row.form.coach == loggedUser.value.id);
        }
      }

      indexedTables.value[key] = tbl.reduce((acc, row) => {
        acc[row.id] = row;
        return acc;
      }, {});
      tables.value[key] = tbl;
    });
    loading.value = false;
    console.log("tables:- ", tables);
  };

  const sort = (sheetName, key, order) => {
    tables.value[sheetName] = tables.value[sheetName].sort((a, b) => {
      if (order === "asc") {
        return a[key] > b[key] ? 1 : -1;
      } else {
        return a[key] < b[key] ? 1 : -1;
      }
    });
  };
  const checkIfRecordCanBeDeleted = (sheetName, id) => {
    const dependentTables = tablesHavingDependentKeys[sheetName];
    if (dependentTables) {
      const dependentTablesData = dependentTables.map(
        (tbl) => tables.value[tbl]
      );
      console.log("dependentTablesData:- ", dependentTablesData);
      const canDelete = dependentTablesData.every((tbl) => {
        return !tbl.some((row) => {
          return row.form[sheetName] === id;
        });
      });
      return canDelete;
    }
    return true;
  };

  const doAdditionalChecks = (sheetName, form) => {
    if (sheetName === "Amount Received" || sheetName === "Remittances Sent") {
      const { month } = form;
      const found = tables.value[sheetName].find(
        (item) => item.form.month === month
      );
      if (found) {
        ElMessage.error("Record already exists for this month.");
        return false;
      }
    }
    if (sheetName === "Coaches") {
      const { email } = form;
      const found = tables.value[sheetName].find(
        (item) => item.form.email === email
      );
      if (found) {
        ElMessage.error("Email already exists.");
        return false;
      }
      sendAccessURL(form);
    }
    return true;
  };

  // const process2Darray = (res) => {
  //   const parsedTables = JSON.parse(res);
  //   let tables_ = {};
  //   let indexedTables_ = {};
  //   Object.keys(parsedTables).forEach((key) => {
  //     let tbl = jsonFrom2DArray(parsedTables[key]);
  //     tbl = tbl.map((row) => {
  //       row.form = JSON.parse(row.form);
  //       return { ...row, ...row.form };
  //     });
  //     indexedTables[key] = tbl.reduce((acc, row) => {
  //       acc[row.id] = row;
  //       return acc;
  //     }, {});
  //     tables[key] = tbl;
  //   });
  //   tables.value = tables_;
  //   indexedTables.value = indexedTables_;
  //   console.log("tables:- ", tables);
  //   console.log("indexedTables:- ", indexedTables);
  // };
  return {
    tables,
    scriptURL,
    getTable,
    indexedTables,
    fetchTables,
    addRow,
    deleteRow,
    chooseAndRunAction,
    duplicateRow,
    sort,
    loading,
    appIsLoading,
    fetchingAllTables,
    duplicatePreviousWeekSchedule,
    selectedRemittanceRow,
    selectRemittanceRow,
    selectedInvoiceRow,
    selectInvoiceRow,
    savePDF,
    sendInvoice,
    loggedUser,
    loggedInstructorName,
    nextInvoiceNumber,
    isAdmin,
    sendInvoiceRequestEmails,
    sendInvoiceRequestEmail,
    openWhatsappweb,
    sendInvoiceRequestWhatsApp,
  };
});
